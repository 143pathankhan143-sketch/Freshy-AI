# freshy_core/ai/__init__.py
