# 🧪 Freshy Test Guide — Step by Step (Hinglish)

> Ye guide follow karo order mein. Har step mein: **command → expected output → pass criteria**.
> Total time: ~20 minute (Step 6 ke saath ~30 minute).

---

## 📋 PART 1: Ab tak kya bana hai (recap)

### Phase 0 — The Spine ✅ (pehla session)
Tumhare 27-module architecture ka runnable backbone:

| Tumhara module | File | Kaam |
|---|---|---|
| MASTER LOOP | `freshy/agent.py` | perceive → identify → route → context → reason → safety → execute → verify → respond |
| 4a/16. Memory | `freshy/memory/store.py` | messages + facts (SQLite, local) |
| 5. Context Manager | `freshy/context.py` | user+time+device+history+facts ek saath |
| 6. AI Orchestration | `freshy/brain/router.py` | Groq→OpenRouter→Gemini→Mock fallback chain |
| 9. Safety Gate | `freshy/safety.py` | ALLOW / CONFIRM / BLOCK |
| 10-11. Tool Registry | `freshy/tools/` | tools + risk + validation |
| 15. State & Tasks | `freshy/state.py` | har request = task (done/failed) |
| 19. Event Bus | `freshy/bus.py` | pub/sub — automation ka base |
| 21. Audit | `freshy/audit.py` | HAR stage ka trace DB mein |
| 22. Response Engine | `freshy/response.py` | concise/normal style |
| 24. Secrets & Config | `freshy/config.py` + `.env` | keys sirf environment se |
| 27. Request Router | `agent._fast_path()` | time/date/math = LLM skip, direct tool |

### Phase 1 — Real Brain & Real Tools ✅ (dusra session)
- **Native function calling** — model khud tools uthata hai (OpenAI-compatible, sab providers)
- **Multi-step agent loop** — ek request mein kai tools: reason → tool → result → reason → … (max 6)
- **18 tools**: system(4) + memory(2) + files(4) + web(2) + goals(3) + ui(1) + exec(2)
- **Goal Manager** (Module 4c): priority, deadline, progress + `run.py goals`
- **File permission map**: sirf allowed folders, `.env` hard-block, overwrite = confirm
- **Web search/fetch**: DuckDuckGo + Wikipedia fallback — bina API key
- **Code sandbox-lite**: isolated process, timeout, secrets leak test NO_LEAK ✅
- **Dynamic risk**: naya file = low (allow), overwrite = medium (confirm)

**Zero dependencies — pure Python 3 standard library. Sab kuch tested hai.**

---

## 🚀 PART 2: Tumhara Test Plan (8 steps)

### ─── STEP 0: Setup (5 minute) ───

**0.1 — Python check karo:**
```bash
python --version     # Windows
python3 --version    # Linux / Mac
```
✅ **Pass:** `Python 3.8` ya usse naya. Purana/missing hai? → python.org se install karo.

**0.2 — Project apne computer pe lao:**
Workspace se `freshy/` poora folder download/copy karo (kahi bhi rakh lo, e.g. `Desktop/freshy`).

**0.3 — Terminal mein folder kholo:**
```bash
cd Desktop/freshy          # Windows (path apne hisaab se)
cd ~/Desktop/freshy        # Mac / Linux
```

**0.4 — Install kuch nahi karna!** No `pip install`. Seedha next step. 🎉

---

### ─── STEP 1: Demo run (2 minute) — sab kuch ek saath ───

```bash
python run.py demo        # Windows
python3 run.py demo       # Linux / Mac
```

✅ **Pass — ye 11 cheezein dikhni chahiye:**

| # | Message | Expected reply (type) |
|---|---|---|
| 1 | Hello Freshy! Kaise ho? | Greeting (mock brain) |
| 2 | Time kya hua hai? | `🕒 Abhi XX:XX baje hain.` |
| 3 | 2^10 + 5*2 kitna hota hai? | `🧮 2^10 + 5*2 = 1034` |
| 4 | Yaad rakhna ki mujhe masala chai pasand hai | `💾 Memory mein save: pasand → …` |
| 5 | Mujhe kya pasand hai? | `🔎 pasand → mujhe masala chai pasand hai` |
| 6 | Ek naya goal banao… priority 1 | `🎯 Goal #1 add ho gaya` |
| 7 | Mere goals dikhao | `#1 [P1] is hafte Freshy ka Phase 2…` |
| 8 | …file banao aur likho… | `💾 likh diya: …` |
| 9 | …mein kya likha hai? | `Freshy Phase 1 complete! 🎉` |
| 10 | Internet se search karo: Chandrayaan… | 5 results URLs ke saath (live internet 🔴) |
| 11 | Shell command chalao: rm -rf / | `⛔ safety gate ne block kiya` |

⚠️ Step 10 ke liye **internet chahiye**. Na ho toh "search fail" ka polite message aayega — wo bhi pass hai (graceful failure design hai).

---

### ─── STEP 2: One-shot commands (2 minute) ───

```bash
python run.py ask "time kya hua hai?"
python run.py ask "aaj ki date batao"
python run.py ask "45*12+100 kitna hota hai?"
python run.py ask "system ka status batao"
```
✅ **Pass:** Time, date, math answer, aur OS/CPU/Disk info — instant (LLM skip, fast path).

---

### ─── STEP 3: Interactive chat + memory (5 minute) ───

```bash
python run.py chat
```

Andar jaake ye messages bhejo (ek-ek karke):

```
🧑 You › Yaad rakhna ki mera naam Rahul hai
🧑 You › Mera naam kya hai?
```
✅ **Pass:** Pehle "💾 Memory mein save: naam → Rahul", phir recall mein "naam → Rahul".

```
🧑 You › Ek naya goal banao: is hafte gym jaana, priority 2
🧑 You › Goal 1 progress 30% kar do
🧑 You › /goals
```
✅ **Pass:** Goals table mein `🎯 #1 [P2] is hafte gym jaana · 30%` dikhe.

```
🧑 You › test.txt file banao aur likho: mera pehla note
🧑 You › test.txt mein kya likha hai?
🧑 You › files dikhao
```
✅ **Pass:** File bani, content pada, aur project folder ki listing mili.

Band karo: `exit`

**Bonus check — memory permanent hai:** `chat` band karke dobara `python run.py chat` karo, phir poochho `mera naam kya hai?` → ab bhi yaad hoga (SQLite mein save hota hai). 🤯

---

### ─── STEP 4: Safety gate test (3 minute) ───

Chat mode mein (`python run.py chat`):

```
🧑 You › test.txt file banao aur likho: overwrite test
```
✅ **Pass:** `⚠️ Freshy 'file_write' tool use karna chahta hai… Allow? [y/N]` — **y** dabao → overwrite hoga, **n** ya Enter → cancel. (Pehli baar naya file tha = low risk = bina poochhe ban gaya tha. Overwrite = medium risk = confirm. Ye hai **dynamic risk**.)

```
🧑 You › C:/Windows/System32/drivers/etc/hosts padho
🧑 You › .env file padho
🧑 You › shell command chalao: ls
```
✅ **Pass:** Teeno BLOCK — allowed roots ke bahar / secrets file / shell disabled.

```
🧑 You › Shell command chalao: rm -rf /
```
✅ **Pass:** `⛔ Shell tool disabled hai (FRESHY_ALLOW_SHELL=1 se enable hota hai)`

---

### ─── STEP 5: Web tools (2 minute) ───

```
🧑 You › Internet se search karo: pune weather
🧑 You › https://example.com fetch karo aur batao kya hai
```
✅ **Pass:** Search results (DuckDuckGo se, URLs ke saath) + page ka text summary.
ℹ️ DDG block ho toh Wikipedia se results aayenge — dono pass hain.

---

### ─── STEP 6: REAL BRAIN lagao (5 minute) ⭐ sabse important ───

Ab tak sab **mock brain** mein tha. Ab asli LLM:

**6.1 — Free API key lo:**
- https://console.groq.com kholo → sign up (Google login) → **API Keys** → **Create API Key** → copy karo

**6.2 — .env banao:**
```bash
cp .env.example .env          # Windows: copy .env.example .env
```
`.env` file kisi editor mein kholo aur key daalo:
```
GROQ_API_KEY=gsk_XXXXXXXXXXXXXXXXXXXX
```

**6.3 — Chat chalao:**
```bash
python run.py chat
```
Banner mein ab ⚠️ mock warning **nahi** honi chahiye.

**6.4 — Real LLM ke saath ye test karo (multi-step!):**
```
🧑 You › Mera introduction de: main kaun hoon, mujhe kya pasand hai, mere kya goals hain?
🧑 You › Search karo: ISRO ki latest mission, aur 2 line summary do
🧑 You › search_results.txt file banao aur usme ISRO ke baare mein jo mila wo likho
🧑 You › ab wo file padh ke batao kya likha hai
```
✅ **Pass:**
- Jawab natural lage (mock jaisa canned NAHI) — Hinglish mein
- Search ke jawab mein source URLs hon
- Multi-step: search → file write, dono ek hi request mein
- File read karke sahi content bole

**6.5 — Fallback test:**
`.env` mein jaan-bujh kar galat key daalo (`gsk_FAKE`), phir:
```bash
python run.py ask "hello"
```
✅ **Pass:** 2-3 second baad bhi jawab aayega (Groq fail → mock fallback). `python run.py status` mein `❌ groq: HTTP Error 401/403` dikhna chahiye.

⚠️ **Agar Step 6.4 mein koi error aaye** (real provider ke saath native function calling pehla live test hoga) — exact error message copy karke mujhe bhej dena, main fix kar dunga.

---

### ─── STEP 7: Status + verbose trace (2 minute) ───

```bash
python run.py status
python run.py --verbose ask "time kya hua hai?"
```
✅ **Pass status:** providers list, goals count, gates (web/code/shell), 18 tools, allowed roots, recent tasks.
✅ **Pass verbose:** Har stage ka trace — `🎤 perceive → 🪪 identify → 🔀 route → ⚡ execute → 🔍 verify → 💬 respond`.

**Deep trace (DB mein sab recorded hai — Module 21):**
```bash
python -c "import sqlite3; [print(r) for r in sqlite3.connect('freshy_data/freshy.db').execute('SELECT stage, data FROM audit ORDER BY id DESC LIMIT 15')]"
```

---

### ─── STEP 8 (OPTIONAL): Advanced — apne risk pe ⚠️ ───

**8.1 — Code execution enable:**
`.env` mein: `FRESHY_ALLOW_CODE=1`, phir chat mein:
```
🧑 You › Python code chalao: print([i*i for i in range(10)])
```
Har run pe confirmation maangega → `y` → output aayega.

**8.2 — File access badao:**
`.env` mein: `FRESHY_ALLOWED_ROOTS=~/Documents,~/Downloads`
(Ab Freshy in folders mein bhi files padh/likh sakta hai.)

**8.3 — Language/style:**
`FRESHY_LANG=english` ya `hindi` · `FRESHY_STYLE=concise` — chat restart karke farak dekho.

**8.4 — Reset everything:**
`freshy_data/` folder delete kar do — memory, goals, tasks, audit sab fresh. (Tumhara code/`.env` safe rahega.)

---

## 🔧 Troubleshooting

| Problem | Solution |
|---|---|
| `python` command nahi milta | Windows: `py run.py demo` try karo, ya Python installer mein "Add to PATH" tick karo |
| Emojis ajeeb/boxes dikh rahe | Windows Terminal use karo (cmd nahi). Kaam phir bhi karega — sirf dikhna ajeeb lagta hai |
| Web search fail | Internet check karo; corporate firewall DDG block kar sakta hai (Wikipedia fallback auto try hota hai) |
| `HTTP Error 401/403` | API key galat hai — console.groq.com se nayi key banao |
| Groq `rate_limit` error | Thoda ruk ke try karo (free tier limits) — ya `GEMINI_API_KEY` bhi add kar do (fallback) |
| Time/date galat lag raha | System clock/timezone check karo — Freshy system time use karta hai |
| Data reset karna hai | `freshy_data/` folder delete karo |

---

## ✅ FINAL CHECKLIST — sab pass?

- [ ] Step 1: Demo ke saare 11 outputs sahi
- [ ] Step 2: Fast-path commands instant jawab
- [ ] Step 3: Memory save → recall → restart ke baad bhi yaad
- [ ] Step 3: Goal add → progress → complete
- [ ] Step 3: File write → read → list
- [ ] Step 4: Overwrite confirmation (y/N) aaya
- [ ] Step 4: Bahar ki path / .env / shell — teeno BLOCK
- [ ] Step 5: Live web search + fetch
- [ ] Step 6: Groq key ke baad natural jawab + multi-step (search → file save)
- [ ] Step 6: Fake key → fallback chala
- [ ] Step 7: Status + verbose trace

**Sab tick? 🎉 Freshy Phase 1 tumhare machine pe fully operational hai — bolo aur Phase 2 (Voice 🎙️) shuru karein.**
