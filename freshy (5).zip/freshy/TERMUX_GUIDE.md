# 📱 Freshy on Termux — A to Z Guide (Mobile-First)

> **Sab kuch SIRF phone se.** Koi laptop nahi, koi desktop nahi.
> Freshy v0.3.0 "Mobile Ready" hai — Termux pe 22 tools milte hain
> (desktop pe 18) — apps kholna, notifications, clipboard, battery sab included.
>
> Total time: ~25-30 minute. Commands copy-paste karo, bas.

---

## ⚠️ PART 0 — Sabse zaroori baat (2 minute padho)

**Termux SIRF F-Droid se install karo. Play Store wala purana aur broken hai**
(update errors, storage issues dega). Ye 90% problems ki jad hai.

---

## 📥 PART A — Apps install (5 minute)

**A1. F-Droid install karo:**
- Phone ke browser mein `f-droid.org` kholo
- **Download F-Droid** → install (Android "unknown sources" permission maangega → Allow)

**A2. Termux install karo:**
- F-Droid app kholo → search **Termux** → **Install**

**A3. Termux:API install karo (recommended):**
- F-Droid mein **Termux:API** bhi install karo
- Ye notifications, clipboard, battery-detail, TTS ke liye chahiye
- (Bina iske bhi Freshy chalega — bas ye features nahi milenge)

**A4. (Optional, baad ke liye)** F-Droid se **Termux:Widget** — one-tap Freshy shortcut ke liye (Part G mein use hoga)

---

## 🖥️ PART B — Termux setup (3 minute)

Termux app kholo aur ye commands ek-ek karke chalao:

```bash
pkg update && pkg upgrade -y
```
```bash
pkg install python unzip nano -y
```
```bash
termux-setup-storage
```
→ Android permission popup aayega → **Allow** dabao. (Ye na karoge toh Download folder access nahi milega.)

**Check (sab sahi hai?):**
```bash
python --version
```
✅ `Python 3.11` ya usse naya dikhna chahiye.

**📱 Termux typing tips (yaad rakhna):**
- **Long-press screen** = copy/paste menu (paste = aise hi karo)
- **Volume Down + Q** = extra keys row (Esc, Ctrl, arrows — bahut kaam aayega)
- **Volume Down = Ctrl** jaisa kaam karta hai (nano mein save = Vol.Down + O)
- **Volume Down + W/A/S/D** = up/left/down/right arrows

---

## 📦 PART C — Freshy phone pe lao (3 minute)

**C1. `freshy.zip` download karo** — is chat ke workspace se (phone browser mein file kholo → download). Phone ke **Download** folder mein save hoga.

**C2. Termux mein ye chalao:**
```bash
cp ~/storage/shared/Download/freshy.zip ~
cd ~
unzip freshy.zip
cd freshy
```

**C3. First run:**
```bash
python run.py demo
```
✅ **Expected:** 11 steps ka demo — greeting, time, math, memory save/recall, goal add/list, file write/read, **live web search**, aur safety block. Sab chala? Freshy tumhare phone pe hai! 🎉

---

## 💬 PART D — Pehli chat (5 minute)

```bash
python run.py chat
```

Ye messages ek-ek karke bhejo:

```
🧑 You › Yaad rakhna ki mera naam [tumhara naam] hai
🧑 You › Mera naam kya hai?
🧑 You › Ek naya goal banao: is hafte Freshy Phase 2 complete karna, priority 1
🧑 You › /goals
🧑 You › test.txt file banao aur likho: mera pehla mobile note
🧑 You › test.txt mein kya likha hai?
🧑 You › Internet se search karo: aaj ka weather Pune
```

Commands: `/status` · `/goals` · `exit` (band karo)

**Memory test (pro level):** chat band karo → dobara `python run.py chat` → poochho `mera naam kya hai?` → Freshy ko ab bhi yaad hoga. 🤯

---

## 📲 PART E — Phone-specific actions (5 minute) ⭐

**E1. Battery/system (koi extra app nahi chahiye):**
```
🧑 You › system ka status batao
```
✅ OS, CPU, storage + battery% dikhega.

**E2. App kholo (koi extra app nahi chahiye!):**
```
🧑 You › WhatsApp kholo
🧑 You › YouTube kholo
🧑 You › Settings kholo
```
✅ App khul jayegi! (Freshy inhe samajhta hai: whatsapp, instagram/insta, youtube/yt, chrome, telegram, gmail, maps, spotify, paytm, gpay, phonepe, settings, playstore. Baaki apps ke liye bolo: *"com.package.name app kholo"*)

**E3. Notification bhejo (Termux:API chahiye):**
```
🧑 You › notification bhejo: khana kha lena bhai
```
✅ Phone pe notification aayegi. ❌ Error aaye toh: `pkg install termux-api` chalao + Termux:API app installed hai check karo (Part A3), phir Termux app ko ek baar close-kholo.

**E4. Clipboard (Termux:API chahiye):**
```
🧑 You › clipboard pe copy karo: ye text copy kar do
🧑 You › clipboard mein kya hai?
```
✅ Pehle clipboard pe text jayega, phir wapas padh ke bolega.

---

## 🧠 PART F — Real brain: FREE AI key (5 minute) ⭐⭐

Ab tak Freshy **mock brain** mein tha (tools sab chalte hain, lekin baat-cheet basic hai). Asli LLM ke liye:

**F1. Key lo (phone ke Chrome se):**
- `console.groq.com` kholo → Google se login → **API Keys** → **Create API Key** → copy

**F2. .env banao:**
```bash
cp .env.example .env
nano .env
```

**F3. Key daalo:**
- `GROQ_API_KEY=` ke aage key paste karo (long-press → Paste)
- Save: **Volume Down + O**, phir Enter
- Exit: **Volume Down + X**

**F4. Models verify karo (important!):**
```bash
python run.py models
```
✅ Groq key ke saath live models list dikhengi + current model ✅ hoga.
(NOTE: Groq ne Aug 2026 mein purane llama models band kar diye the —
Freshy ka default ab `openai/gpt-oss-120b` hai, aur model band ho toh
Freshy khud alternate pe switch kar leta hai.)

**F5. Ab asli Freshy:**
```bash
python run.py chat
```
✅ Banner mein mock warning nahi dikhegi. Ab try karo:
```
🧑 You › Mera introduction de — main kaun hoon, kya pasand hai, mere goals kya hain?
🧑 You › Search karo: ISRO ki latest mission, 2 line summary do
🧑 You › search_results.txt banao aur usme ISRO ka jo mila wo likho
🧑 You › ab wo file padh ke sunao
```
✅ Natural Hinglish jawab + multi-step kaam (search → file save) + tumhari memory/goals ka use — sab ek saath.

---

## ⚙️ PART G — Daily-use setup (2 minute)

**G1. Shortcut — bas `freshy` likhna:**
```bash
echo "alias freshy='cd ~/freshy && python run.py chat'" >> ~/.bashrc
source ~/.bashrc
freshy
```
✅ Ab Termux kholte hi `freshy` likho — chat shuru.

**G2. Apni poori storage access do (recommended):**
```bash
nano ~/freshy/.env
```
Is line ko uncomment/edit karo:
```
FRESHY_ALLOWED_ROOTS=~/storage/shared
```
Save-exit (Vol.Down+O, Vol.Down+X). Ab Freshy tumhari **Download, Documents, photos ke folders** tak files padh/likh sakta hai:
```
🧑 You › Download folder mein kya files hain?
🧑 You › Download/notes.txt padho
```

**G3. (Optional) One-tap home-screen shortcut:**
```bash
mkdir -p ~/.shortcuts
echo '#!/data/data/com.termux/files/usr/bin/bash
cd ~/freshy && python run.py chat' > ~/.shortcuts/freshy.sh
chmod +x ~/.shortcuts/freshy.sh
```
Termux:Widget app → widget add karo → **freshy** shortcut → home screen pe one-tap Freshy! 🚀

---

## 🔧 PART H — Mobile tips & troubleshooting

| Problem | Fix |
|---|---|
| Play Store se Termux install kiya | Uninstall → F-Droid wala install (Part 0/A) |
| `python: not found` | `pkg install python -y` |
| `unzip: not found` | `pkg install unzip -y` |
| `termux-setup-storage` ne permission nahi maangi | Android Settings → Apps → Termux → Permissions → Storage ON, phir dobara chalao |
| Storage access (`~/storage/shared`) nahi mila | `termux-setup-storage` dobara chalao |
| Notification/clipboard error: "Termux:API chahiye" | `pkg install termux-api -y` + F-Droid se Termux:API app + Termux restart |
| Web search fail | Mobile data/WiFi check; DDG slow ho toh Wikipedia fallback auto chalta hai |
| Groq `HTTP Error 401/403` | Key galat/expired — console.groq.com se nayi key banao, .env update karo (ya line delete karo — Gemini already chal rahi hai toh zaroorat nahi) |
| Gemini/Groq ke baad "MOCK brain" jawab | Screen pe `⚠️ provider fail` warning dekho — `python run.py status` mein exact error |
| Groq `403 error code: 1010` | Cloudflare Python-urllib ko block karta tha — **v0.3.4 mein fix ho gaya** (User-Agent header). Naya zip lo |
| Gemini `429` "exceeded your current quota" | Free tier limit khatam. Per-minute limit ho toh 1 min ruko (Freshy ab khud 2.5s retry karta hai). **Daily quota** ho toh Pacific midnight (~12:30 PM IST) pe reset — tab tak Groq primary use karo |
| open_url har baar permission maangta tha | v0.3.7 se risk=low — URL seedha khulta hai, koi confirm nahi |
| App kholna fail ho raha tha (WhatsApp/YouTube installed hone ke bawajood) | Naye Android pe `cmd`/`monkey` Termux se block ho jaate hain — v0.3.7 mein intent-URI tarika hai jo system se seedha kholta hai |
| App nahi khul rahi / Freshy package name maang raha hai | v0.3.6 mein common naam seedha chalta hai — "whatsapp kholo", "youtube kholo", "paytm kholo". Naam na mile to Freshy phone ki installed app list mein khud dhoondhta hai |
| Chat karte waqt achanak `Killed` | Android ne Termux background mein maar diya (app/browser khulne par hota hai — Freshy ka bug nahi!). v0.3.6 se chat khud wake-lock le leta hai. Extra: `termux-wake-lock` + Phone Settings → Apps → Termux → Battery → **Unrestricted**. Data loss nahi hota — `python run.py chat` dobara chalao |
| `Exec format error: 'monkey'` (app open) | v0.3.3 mein fix ho gaya — naya zip lo. (Android pe monkey script hai, Freshy ab `am start` use karta hai) |
| `model_decommissioned` / model band ho gaya | `python run.py models` chalao — Freshy auto-switch karta hai; manually badalna ho toh .env mein `FRESHY_MODEL_GROQ=openai/gpt-oss-120b` |
| Groq `rate_limit` | Free tier limit — thoda ruk ke try karo, ya Gemini key bhi add kar do |
| Battery jaldi khatam (long sessions) | Android Settings → Apps → Termux → Battery → **Unrestricted** |
| Session band hone pe process mar jata hai | Voice/background Phase 2 mein `termux-wake-lock` se fix hoga |
| Sab data reset karna hai | `rm -rf ~/freshy/freshy_data` (memory/goals/tasks/audit sab fresh; code safe) |
| Naya freshy.zip aaya | `cd ~ && unzip -o freshy.zip` (overwrite; tumhara .env + data safe rahega) |

**Pro tip:** Freshy ka data sab local hai (`~/freshy/freshy_data/`) — koi cloud nahi, koi tracking nahi.

---

## 🚀 PART I — Aage kya? (Mobile-first roadmap)

**Phase 2 (Voice) ka mobile-first plan — laptop se bhi aasan:**
- **Bolna:** `termux-tts-speak "kuch bhi"` — Android ka built-in TTS turant use hoga (Termux:API). Freshy isi se bolega — koi heavy setup nahi!
- **Sunna:** `termux-mic-record` se audio lena → `faster-whisper` (Termux mein `pip install` hota hai) se Hindi/Hinglish/English STT
- **Wake lock:** `termux-wake-lock` — screen band ho tab bhi Freshy jage rahe
- **Wake word** ("Hey Freshy"): baad mein, VAD + STT se

Baaki roadmap (speaker ID, automation, multi-device) `ROADMAP.md` mein — sab Termux-pe-compatible rakhenge. 📱

---

## ✅ FINAL CHECKLIST (mobile)

- [ ] F-Droid se Termux + Termux:API install
- [ ] `python --version` kaam kar raha
- [ ] `freshy.zip` → unzip → `python run.py demo` ke 11 steps pass
- [ ] Chat: memory + goals + files + web search
- [ ] "WhatsApp kholo" → app khuli
- [ ] "system ka status batao" → battery% dikha
- [ ] Notification + clipboard (Termux:API ke baad)
- [ ] Groq key → real LLM + multi-step (search → file save)
- [ ] `freshy` alias + storage access (`~/storage/shared`)

**Sab tick? 🎉 Congrats bhai — tumhare pocket mein apna personal AI runtime hai.**
**Phase 2 (Voice 🎙️) ke liye ready ho to bolo!**
