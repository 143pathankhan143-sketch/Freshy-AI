#!/usr/bin/env python3
"""Freshy CLI — Phase 1: Real Brain & Real Tools.

  python run.py demo                    # scripted pipeline demo (Phase 1)
  python run.py chat                    # interactive chat (REPL)
  python run.py ask "time kya hua?"     # one-shot question
  python run.py goals                   # goal manager (Module 4c)
  python run.py status                  # providers, tools, gates, memory
  python run.py models                  # live model check (Groq/Gemini/OpenRouter)
  python run.py --verbose demo          # poora master-loop trace

Windows pe `python`, Linux/Mac pe `python3` use karo.
Koi dependency install nahi karni — pure Python standard library.
"""
import argparse
import subprocess
import sys

from freshy.main import FreshyApp
from freshy.tools.android import is_termux


def banner():
    env = "📱 Termux (Android)" if is_termux() else "🖥️ Desktop"
    return ("──────────────────────────────────────────────────────\n"
            f"  🧠 FRESHY · v0.3.7 · Mobile Ready · {env}\n"
            "  native function calling · multi-step agent\n"
            "──────────────────────────────────────────────────────")

MOCK_HINT = (
    "⚠️  Koi AI provider key nahi mili — MOCK brain mode mein hoon.\n"
    "   (file/web/goal/time tools phir bhi poore kaam karte hain!)\n"
    "   Real LLM ke liye .env banao (dekho: .env.example).\n"
    "   GROQ_API_KEY free milti hai: https://console.groq.com\n"
)


def safe_print(*args, **kwargs):
    """Windows console (cp1252) emoji pe crash na ho isliye."""
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        text = " ".join(str(a) for a in args).encode("ascii", "replace").decode()
        end = kwargs.get("end", "\n")
        print(text, end=end)


def ask_input(prompt, fallback_prompt="You › "):
    try:
        return input(prompt)
    except UnicodeEncodeError:
        return input(fallback_prompt)


# ────────────────────────── commands ──────────────────────────
def cmd_chat(app, args):
    safe_print(banner())
    if app.router.using_mock_only:
        safe_print(MOCK_HINT)
    if is_termux():
        try:
            subprocess.run(["termux-wake-lock"], capture_output=True, timeout=5)
            safe_print("🔋 Wake-lock ON — session ab background mein bhi zyada safe hai")
            safe_print("   (Phir bhi 'Killed' aaye to: Settings → Apps → Termux → Battery → Unrestricted)\n")
        except Exception:
            safe_print("🔋 Tip: `termux-wake-lock` manually chalao — background mein")
            safe_print("   Android Termux session ko maar sakta hai (\"Killed\")\n")
    safe_print("Commands: exit/quit = band · /status · /goals\n")
    while True:
        try:
            line = ask_input("🧑 You › ").strip()
        except (EOFError, KeyboardInterrupt):
            safe_print("\n👋 Alvida!")
            break
        if not line:
            continue
        if line.lower() in ("exit", "quit"):
            safe_print("👋 Alvida!")
            break
        if line.lower() == "/status":
            cmd_status(app)
            continue
        if line.lower() == "/goals":
            cmd_goals(app)
            continue
        try:
            reply = app.handle(line, interactive=True)
        except KeyboardInterrupt:
            safe_print("\n⚠️ Jawab rok diya (Ctrl+C) — sawaal dobara bhejo, ya 'exit' likho.\n")
            continue
        safe_print("🤖 Freshy ›", reply, "\n")


def cmd_ask(app, args):
    if app.router.using_mock_only:
        safe_print(MOCK_HINT)
    message = " ".join(args.message)
    safe_print("🤖 Freshy ›", app.handle(message, interactive=False))


def cmd_demo(app, args):
    import random

    tag = "".join(random.choices("abcdefghjkmnpqrstuvwxyz23456789", k=6))
    note_file = f"freshy_data/demo_note_{tag}.txt"
    demo_script = [
        ("CORE — mock brain greeting", "Hello Freshy! Kaise ho?"),
        ("FAST — direct tool, LLM skip", "Time kya hua hai?"),
        ("FAST — math", "2^10 + 5*2 kitna hota hai?"),
        ("AGENT — memory save (remember tool)", "Yaad rakhna ki mujhe masala chai pasand hai"),
        ("AGENT — memory recall", "Mujhe kya pasand hai?"),
        ("AGENT — goal add (Goal Manager, Module 4c)", "Ek naya goal banao: is hafte Freshy ka Phase 2 complete karna, priority 1"),
        ("AGENT — goal list", "Mere goals dikhao"),
        ("AGENT — file write (permission map + new file = low risk)", f"{note_file} file banao aur likho: Freshy Phase 1 complete! 🎉"),
        ("AGENT — file read", f"{note_file} mein kya likha hai?"),
        ("AGENT — web search (live internet)", "Internet se search karo: Chandrayaan mission latest update"),
        ("SAFETY — blocked action (shell disabled)", "Shell command chalao: rm -rf /"),
    ]
    safe_print(banner())
    safe_print("— DEMO: Phase 1 pipeline live dikhata hai —\n")
    for label, message in demo_script:
        safe_print(f"▶ {label}")
        safe_print(f"🧑 You › {message}")
        safe_print(f"🤖 Freshy › {app.handle(message)}\n")
    safe_print("Goals CLI se bhi dekho:      python run.py goals")
    safe_print("Apne words mein try karo:    python run.py chat")
    safe_print("Poora trace:                 python run.py --verbose demo\n")


def cmd_goals(app, args=None):
    goals = app.goals.all_recent(15)
    line = "─" * 60
    safe_print(line)
    safe_print("🎯 FRESHY GOALS")
    safe_print(line)
    if not goals:
        safe_print("Koi goal nahi. Chat mein try karo: 'ek naya goal banao: …'")
    for g in goals:
        mark = "✅" if g["status"] == "done" else ("🗂️" if g["status"] == "archived" else "🎯")
        deadline = f" · ⏰ {g['deadline']}" if g["deadline"] else ""
        progress = f" · {g['progress']}%" if g["progress"] else ""
        safe_print(f"{mark} #{g['id']} [P{g['priority']}] {g['goal'][:58]}{deadline}{progress}")
    safe_print(line)
    safe_print("Chat mein: 'goal 1 complete kar do' · 'goal 2 progress 50%'")


def cmd_status(app, args=None):
    s = app.status()
    line = "─" * 52
    safe_print(line)
    safe_print("🩺 FRESHY STATUS")
    safe_print(line)
    env = "📱 Termux (Android)" if s.get("environment") == "termux" else "🖥️ Desktop"
    safe_print(f"Environment  : {env}")
    keys_line = " · ".join(
        f"{label}={'✅ set' if (app.config.get(var) or '').strip() else '❌ missing'}"
        for label, var in (("GROQ_API_KEY", "GROQ_API_KEY"),
                           ("GEMINI_API_KEY", "GEMINI_API_KEY"),
                           ("OPENROUTER_API_KEY", "OPENROUTER_API_KEY"))
    )
    safe_print("Env keys     : " + keys_line)
    safe_print(f"Session      : {s['session']}")
    providers = ", ".join(s["providers"])
    safe_print(f"AI providers : {providers}" + ("   ⚠️ MOCK-ONLY MODE" if s["mock_only"] else ""))
    memory = s["memory"]
    goals = s["goals"]
    safe_print(f"Memory       : {memory['messages']} messages · {memory['facts']} facts")
    safe_print(f"Goals        : {goals['active']} active · {goals['done']} done")
    gates = s["gates"]
    safe_print(f"Gates        : web={gates['web']} · code_run={gates['code_run']} · shell={gates['shell']} · max_steps={gates['max_agent_steps']}")
    safe_print("File access  : " + " | ".join(s["allowed_roots"]))
    caps = s["capabilities"]
    safe_print(f"Capabilities : {len(caps)} tools")
    row, rows = [], []
    for cap in caps:
        row.append(f"{cap['name']}({cap['risk']})")
        if len(row) == 4:
            rows.append("  " + " · ".join(row))
            row = []
    if row:
        rows.append("  " + " · ".join(row))
    for r in rows:
        safe_print(r)
    safe_print("Safety       : " + s["safety"]["policy"])
    tasks = s["recent_tasks"]
    if tasks:
        safe_print("Recent tasks :")
        for t in tasks:
            safe_print(f"  [{t['status']:>7}] {t['goal'][:60]}")
    provider_health = s["health"]["providers"]
    if provider_health:
        safe_print("Provider health (is session):")
        for name, h in provider_health.items():
            mark = "✅" if h["ok"] else "❌"
            safe_print(f"  {mark} {name}: {h.get('error') or 'ok'}")
    else:
        # DB se aakhri failures — naye process mein bhi dikhen
        fallbacks = app.audit.recent("provider.fallback", 3)
        if fallbacks:
            safe_print("Provider health (aakhri failures, DB se):")
            for fb in fallbacks:
                safe_print(f"  ❌ {fb.get('provider')}: {str(fb.get('error'))[:90]}")
    safe_print(line)


def cmd_models(app, args=None):
    line = "─" * 52
    safe_print(line)
    safe_print("📡 FRESHY MODELS — live check")
    safe_print(line)
    if app.router.using_mock_only:
        safe_print("Koi API provider configured nahi (.env mein key daalo).")
        safe_print("Current chain: mock (offline)")
        safe_print(line)
        safe_print("Free key: https://console.groq.com")
        return
    for provider in app.router.chain:
        if not hasattr(provider, "list_models"):
            continue
        safe_print(f"\n📡 {provider.name}  ·  current model: {provider.current_model}")
        try:
            models = provider.list_models()
            safe_print(f"   {len(models)} models live:")
            safe_print("   " + ", ".join(models[:12]))
            if len(models) > 12:
                safe_print(f"   … +{len(models) - 12} more")
            current = provider.current_model
            if current in models:
                safe_print("   ✅ current model available hai")
            elif current == "openrouter/auto" or current.endswith("-latest"):
                safe_print(f"   ✅ '{current}' = routing/latest alias — hamesha valid")
            else:
                safe_print("   ⚠️ current model list mein NAHI hai — .env mein badlo:")
                safe_print(f"      FRESHY_MODEL_{provider.name.upper()}=<model-id>")
                options = [m for m in models if "gpt-oss" in m][:5] or models[:5]
                safe_print(f"      Options: {', '.join(options)}")
        except Exception as exc:
            safe_print(f"   ❌ list nahi mila: {str(exc)[:120]}")
    safe_print("\n" + line)
    safe_print("Note: model band ho jaye toh Freshy AUTOMATICALLY alternate try karta hai.")
    safe_print("Override: .env mein FRESHY_MODEL_GROQ=... / _GEMINI=... / _OPENROUTER=...")


# ────────────────────────── entry ──────────────────────────
def main():
    parser = argparse.ArgumentParser(
        prog="freshy",
        description="Freshy — personal AI assistant runtime (Phase 1: Real Brain & Real Tools)",
    )
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="master loop ka har stage print karo (audit trace)")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("chat", help="interactive chat mode")
    ask_parser = sub.add_parser("ask", help="one-shot question")
    ask_parser.add_argument("message", nargs="+", help="Freshy se kuch poochho")
    sub.add_parser("demo", help="scripted pipeline demo (Phase 1)")
    sub.add_parser("goals", help="goal manager — goals dikhao")
    sub.add_parser("status", help="providers, tools, gates, memory")
    sub.add_parser("models", help="live model check — kaunse models available hain")

    args = parser.parse_args()
    if not args.cmd:
        parser.print_help()
        safe_print("\nSabse pehle try karo:  python run.py demo")
        sys.exit(0)

    app = FreshyApp(verbose=args.verbose)
    commands = {"chat": cmd_chat, "ask": cmd_ask, "demo": cmd_demo,
                "goals": cmd_goals, "status": cmd_status, "models": cmd_models}
    commands[args.cmd](app, args)


if __name__ == "__main__":
    main()
