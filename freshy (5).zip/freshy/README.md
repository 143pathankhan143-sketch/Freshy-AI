# 🧠 Freshy — Phase 1: Real Brain & Real Tools · 📱 Mobile Ready

> Tumhare 27-module architecture ka runnable implementation.
> **Phase 0** ne spine banaya (master loop, memory, safety, audit) —
> **Phase 1** ne usko asli dimaag aur asli tools de diye.

## ⚡ Quickstart

```bash
# Koi install nahi — pure Python 3 standard library
python run.py demo              # Phase 1 pipeline demo (files, goals, web, safety)
python run.py chat              # interactive chat (REPL)
python run.py ask "time kya hua hai?"
python run.py goals             # 🎯 goal manager (Module 4c)
python run.py status            # 18 tools · gates · memory · providers
python run.py models            # 📡 live model check (Groq/Gemini/OpenRouter)
python run.py --verbose demo    # poora multi-step trace
```

Windows pe `python`, Linux/Mac pe `python3`.

📱 **Termux (Android) pe chalana hai?** `TERMUX_GUIDE.md` kholo — A-to-Z mobile setup. Termux pe Freshy ke 22 tools hote hain (apps kholna, notification, clipboard, battery — desktop pe 18).

## 🆕 Phase 1 mein kya naya hai

| Feature | Kya hai |
|---|---|
| **Native function calling** | Tools ab OpenAI-compatible `tools` spec se jaate hain — model khud `tool_calls` mein tool uthata hai. (Phase 0 ka JSON protocol khatam.) Groq / OpenRouter / Gemini sab same format. |
| **Multi-step agent loop** | Ek request mein model kai tools chala sakta hai: reason → tool → result dekho → agla step → … final jawab (max `FRESHY_MAX_STEPS`). |
| **File tools + permission map** | `file_read/write/list/search` — sirf ALLOWED ROOTS ke andar, `.env` jaisi secrets pe hard block. |
| **Web tools (bina API key)** | `web_search` (DuckDuckGo → Wikipedia fallback) + `web_fetch` (HTML → clean text). |
| **Goal Manager (Module 4c)** | Goals + priority + deadline + progress. Context mein hamesha active goals — Freshy unhe "yaad" rakhta hai. `python run.py goals` |
| **Code sandbox-lite** | `code_run` — isolated process + timeout + secrets child process mein kabhi nahi jaate. Default OFF. |
| **Dynamic risk** | Naya file likhna = low risk (seedha allow), overwrite = medium (confirm maango). |

## 🧠 Real brain lagao (2 minute)

```bash
cp .env.example .env        # Windows: copy .env.example .env
# EK bhi key daalo — sab free options hain:
#   GROQ_API_KEY       console.groq.com        ← recommended (free)
#   GEMINI_API_KEY     aistudio.google.com
#   OPENROUTER_API_KEY openrouter.ai
python run.py chat
```

Key fail → automatic next provider → last resort mock brain (offline hamesha chalta hai).

## 🛠️ 18 Tools (Module 10-11)

| Category | Tools | Risk |
|---|---|---|
| System | `time_now` `date_today` `math_eval` `system_stats` | low |
| Memory | `remember` `recall` | low |
| Files | `file_list` `file_read` `file_search` `file_write` | low · **overwrite = medium** |
| Web | `web_search` `web_fetch` | low |
| Goals | `goal_add` `goal_list` `goal_update` | low |
| UI | `open_url` | medium (confirm) |
| Android (📱 Termux only) | `open_app` `notify` `clipboard_get` `clipboard_set` | low |
| Exec | `code_run` `shell` | **high — default OFF + confirm** |

**Naya tool 5 lines mein:**
```python
class JokeTool(Tool):
    name = "joke"
    description = "Ek chhota joke sunata hai"
    parameters = {"type": "object", "properties": {}, "required": []}
    risk = "low"
    def run(self, args):
        return "Programmer ka favourite breakfast? Foo Bar 😄"
```
`build_registry()` mein register karo — bas. Native function calling khud handle karega.

## 🔒 Safety (Module 9) — har tool call pe

```
unknown tool          → ❌ BLOCK
precheck fail         → ❌ BLOCK   (disabled tool, bahar ki path, .env, web off)
risk low              → ✅ ALLOW   (naya file likhna bhi low hai)
risk medium           → ⚠️ CONFIRM (overwrite, browser open)
risk high             → ⚠️ CONFIRM (shell/code_run — agar enabled hain)
non-interactive mode  → auto-deny (safe side)
```

## 🗺️ Tumhara diagram → code

| Module | Code | Phase |
|---|---|---|
| 1. Perception (text) | `run.py` | ✅ 0 (voice → 2) |
| 2. Speaker Identity | `freshy/identity.py` | 🟡 text (voice → 3) |
| 3. Identity & Session | `freshy/identity.py` | ✅ 0 |
| 4. Freshy Core | `freshy/core.py` | ✅ |
| 4a. Memory | `freshy/memory/store.py` | ✅ (vectors → 4) |
| 4b. AI Brain | `freshy/brain/` | ✅ native function calling |
| **4c. Goal Manager** | `freshy/goals.py` | ✅ **1** |
| 5. Context Manager | `freshy/context.py` (+goals) | ✅ |
| 6. Orchestration/Router | `freshy/brain/router.py` | ✅ fallback chain |
| **7. Planner (multi-step)** | `freshy/agent.py` loop | ✅ **1** |
| 8. Agent Engine | `freshy/agent.py` | ✅ |
| 9. Safety Gate | `freshy/safety.py` + har tool ka `precheck`/`risk_for` | ✅ **file access rules bhi** |
| 10-11. Registries | `freshy/tools/` | ✅ **1: JSON-schema specs** |
| 12. Execution | `agent._execute()` | ✅ + sandbox-lite |
| 13-14. Observe/Verify | `agent` (per-step audit) | ✅ |
| 15. State & Tasks | `freshy/state.py` | ✅ |
| 16. Memory & Learning | `freshy/memory/store.py` | 🟡 (learning → 4) |
| 17-18. Automation/Autonomy | `freshy/bus.py` hooks | 🟡 Phase 4 |
| 19. Event Bus | `freshy/bus.py` | ✅ |
| 20. Health | `freshy/health.py` | ✅ |
| 21. Audit | `freshy/audit.py` | ✅ |
| 22. Response Engine | `freshy/response.py` | ✅ |
| 23. Voice Engine | — | ⬜ Phase 2 |
| 24. Secrets & Config | `freshy/config.py` + `.env` | ✅ |
| 25. Privacy | local SQLite · secrets env-only · sandbox env-scrub | 🟡 |
| 26. Concurrency | — | ⬜ Phase 5 |
| 27. Request Router | `agent._fast_path()` | ✅ |
| **MASTER LOOP** | `freshy/agent.py → handle()` | ✅ |

## 🐍 Master loop — ab multi-step

```
agent.handle(text)
 ├─ 🎤 perceive → 🪪 identify → 🔀 route (FAST/AGENT)
 ├─ 🧩 context (facts + goals + device + history)
 ├─ 🧠 REASON ←──────────────┐
 │    ↓ tool_calls?          │
 ├─ 🔐 safety → ⚡ execute → 👁 observe → 🔍 verify
 │    ↓ tool result ─────────┘ (max 6 steps)
 ├─ 🗃 state → 💾 memory → 💬 respond
```

Trace: `python run.py --verbose demo` · DB mein: `SELECT stage, data FROM audit ORDER BY id DESC LIMIT 30`

## ⚙️ Configuration (`.env`)

| Variable | Default | Kya karta hai |
|---|---|---|
| `GROQ_API_KEY` / `GEMINI_API_KEY` / `OPENROUTER_API_KEY` | — | AI providers (fallback chain) |
| `FRESHY_MODEL_GROQ` / `_GEMINI` / `_OPENROUTER` | provider default | model override — live list: `run.py models` |
| `FRESHY_ALLOWED_ROOTS` | project folder | **file access permission map** (comma-separated) |
| `FRESHY_MAX_STEPS` | 6 | agent loop ki limit |
| `FRESHY_ENABLE_WEB` | 1 | web tools on/off |
| `FRESHY_ALLOW_CODE` | 0 | code_run enable (HIGH RISK) |
| `FRESHY_ALLOW_SHELL` | 0 | shell enable (HIGH RISK) |
| `FRESHY_USER_NAME` / `FRESHY_LANG` / `FRESHY_STYLE` | Boss / hinglish / normal | persona |

## 🔒 Honest security notes

- `code_run` **sandbox-lite** hai (isolated process + timeout + env-scrub) — Docker-grade nahi. Isliye default OFF + har run pe confirmation. True sandbox Phase 5.
- Secrets (`.env`) sirf environment se — logs/audit/child-process mein kabhi nahi (tested: `NO_LEAK`).
- File tools allowed roots ke bahar kuch nahi chhu sakte.
- Mock brain offline chalta hai — demo/dev ke liye; real jawab ke liye API key daalo.

## 📁 Structure

```
freshy/
├── run.py                  # CLI: chat · ask · demo · goals · status
├── freshy/
│   ├── main.py             # FreshyApp — wiring (composition root)
│   ├── agent.py            # 🫀 master loop + multi-step planner
│   ├── core.py             # system prompt + messages builder
│   ├── brain/              # providers (native function calling) + router
│   ├── memory/store.py     # messages + facts (SQLite)
│   ├── goals.py            # 🎯 Goal Manager + goal tools (Module 4c)
│   ├── tools/              # base + builtin + files + web + code_run
│   ├── safety.py           # permission gate (precheck + dynamic risk)
│   ├── context.py          # unified context (+ goals)
│   ├── identity.py · state.py · bus.py · audit.py · health.py · response.py
├── freshy_data/            # tumhara local data (git mein mat daalna)
├── ROADMAP.md              # Phase 2 (voice) → Phase 5
├── TERMUX_GUIDE.md         # 📱 A-to-Z mobile (Termux) guide
├── TEST_GUIDE.md           # 🧪 step-by-step test guide
└── .env.example
```

## ➡️ Aage: Phase 2 — Voice 🎙️

Mic → VAD → wake word ("Hey Freshy") → faster-whisper STT → yahi core → Piper/Gemini TTS → barge-in.
Roadmap `ROADMAP.md` mein.
