# 🗺️ Freshy — Architecture → Real Life Conversion Roadmap

> **Ek hi golden rule: har phase ke baad Freshy runnable rahega.**
> Pehle spine (Phase 0), phir har phase mein depth.

---

## Phase 0 — The Spine ✅ (HO GAYA)

Master loop, event bus, config/secrets, SQLite memory, safety gate,
audit trail, health monitor, model router (fallback chain),
fast-path request router, CLI (chat/ask/demo/status).

---

## Phase 1 — Real Brain & Real Tools ✅ (HO GAYA)

- [x] **Native function calling** — OpenAI-compatible `tools` specs,
      model `tool_calls` mein tools uthata hai (JSON protocol retired)
- [x] **File tools** — read/write/list/search + permission map
      (`FRESHY_ALLOWED_ROOTS`), `.env` hard-block, overwrite = confirm
- [x] **Web tools** — DuckDuckGo search (Wikipedia fallback) + URL fetch
      (HTML → text) — bina kisi API key, pure stdlib
- [x] **Multi-step planner** — agent loop: reason → tool → observe →
      verify → … → final (max `FRESHY_MAX_STEPS`)
- [x] **Code exec sandbox-lite** — isolated process (`python -I`) +
      timeout + secrets env-scrub (default OFF, har run pe confirm)
- [x] **Goal Manager (Module 4c)** — goals, priority, deadline,
      progress; context mein active goals; `python run.py goals`

**User ke liye ek kaam bacha hai:** `.env` mein API key daal kar
real-provider function calling ka ek test (`python run.py chat` mein
files/web/goals wale commands try karo) — mock mode mein sab test ho chuka.

---

## Phase 2 — Voice 🎙️ (effort: 2–3 weekends) — *sabse maza aayega*

```
mic → VAD → wake word → STT → [yahi Phase 1 core] → TTS
```

- [ ] Mic capture + **VAD** (silero-vad — lightweight, ONNX)
- [ ] **Wake word** — "Hey Freshy!" (openWakeWord = open source;
      ya Porcupine free tier)
- [ ] **STT**: `faster-whisper` (small/medium) — Hindi + English +
      code-mixed Hinglish handle karta hai
      (Vosk = ultra-light option, Hinglish accuracy kam)
- [ ] **TTS**: `Piper` (fast, local) ya Gemini TTS (cloud, best quality);
      XTTS voice-clone — baad mein
- [ ] **Barge-in**: user bola → Freshy chup (speech queue + interrupt)
- [ ] Startup greeting + mute-when-user-speaks
- [ ] Language auto-detect (Hindi/Hinglish/English)

**Tech:** `sounddevice`, `faster-whisper`, `piper-tts`, `silero-vad`

**📱 Mobile-first shortcut (Termux):** bolna TURANT possible hai — `termux-tts-speak` (Android TTS, Termux:API se, zero setup). Sunna: `termux-mic-record` ya faster-whisper (Termux pip se install hota hai). Wake lock: `termux-wake-lock` — screen band hone pe bhi Freshy jage rahe. Ye rasta desktop setup se bhi fast hai.

---

## Phase 3 — Speaker Identity 🪪 (effort: 1 weekend)

- [ ] **Enrollment**: 5 voice samples → speaker embeddings
      (Resemblyzer = easy; SpeechBrain ECAPA = better accuracy)
- [ ] **Runtime verification**: embedding cosine similarity + threshold
      → `match_score` → `IdentityEngine` mein plug (interface ready hai)
- [ ] **Trust states**: owner ki awaaz → full access;
      unknown/guest → sirf safe replies
- [ ] **Anti-spoof**: honest note — replay-attack detection hard hai;
      liveness heuristics + sensitive actions pe extra confirmation

**Tech:** `resemblyzer` ya `speechbrain`

---

## Phase 4 — Memory++ & Automation ⚙️ (effort: 2 weekends)

**Memory (Module 16 ka pura version):**
- [ ] Vector memory: `sentence-transformers` (multilingual — Hinglish
      ke liye) + `sqlite-vec` ya Chroma
- [ ] Importance scoring + expiration (bhoolna bhi zaroori hai 😄)
- [ ] Successful/failed actions ka feedback loop

**Automation (Modules 17-18):**
- [ ] Scheduler: `APScheduler` (cron, one-shot, recurring)
- [ ] Event rules existing bus pe: `trigger → condition → action`
- [ ] File watcher (`watchdog`), webhook endpoint (FastAPI)
- [ ] Example goal: *"subah 8 baje weather + calendar + top tasks
      ki voice briefing do"* (Phase 2 ke baad)

---

## Phase 5 — Hardening & Multi-device 🛡️ (ongoing)

- [ ] FastAPI service — Freshy network pe (phone/browser se access)
- [ ] Android: Termux mein direct YA Kotlin app jo backend call kare
- [ ] Encryption at rest (SQLCipher / Fernet), log redaction
- [ ] **True sandbox** (Docker/Firejail) shell/code tools ke liye —
      abhi wala sandbox-lite hai
- [ ] asyncio concurrency + supervisor auto-restart (Module 26)
- [ ] Token/cost metering per provider

---

## 📜 Golden rules

1. **Runnable > Complete.** Har weekend ke baad working demo.
2. **Provider abstraction thin rakho** — ek OpenAI-compat client, sab providers.
3. **Secrets sirf env mein.** Code/log/UI/child-process mein kabhi nahi.
4. **Mock mode hamesha kaam kare** — offline dev + demos + fallback.
5. **Audit sab kuch** — trace hi debugging bachata hai.
6. **Complexity tabhi jodna jab zaroorat ho** (YAGNI).

## 🎯 Honest reality-check

Phase 0 → 1 se tumhare paas ab ek **real AI assistant runtime** hai —
multi-step tools, memory, goals, web, files, safety. Phase 2 (voice) ke
baad hi ~90% "apna personal JARVIS" experience complete ho jata hai.
Poora 27-module production system team-months ka kaam hai — phased
raho, har step pe enjoy karo. 🚀
