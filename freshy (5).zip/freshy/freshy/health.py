"""Freshy — Health & Observability (Architecture Module 20).

Provider health, uptime, error tracking. `python run.py status` yahi dikhata hai.
"""
import datetime


class HealthMonitor:
    def __init__(self):
        self.started = datetime.datetime.now()
        self.providers = {}

    def record(self, name, ok, error=None):
        self.providers[name] = {
            "ok": ok,
            "error": (str(error)[:160] if error else None),
            "last_used": datetime.datetime.now().strftime("%H:%M:%S"),
        }

    def snapshot(self):
        return {
            "uptime_sec": round((datetime.datetime.now() - self.started).total_seconds(), 1),
            "providers": dict(self.providers),
        }
