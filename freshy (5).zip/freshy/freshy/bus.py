"""Freshy — Event Bus (Architecture Module 19).

Central communication system: koi bhi module event publish kare,
koi bhi module subscribe kare. Phase 0 mein audit bridge subscribe
karta hai; Phase 4 mein automation engine isi pe rules chalayega:

    trigger → condition → action
"""


class EventBus:
    def __init__(self):
        self._subscribers = {}

    def subscribe(self, topic, handler):
        self._subscribers.setdefault(topic, []).append(handler)

    def publish(self, topic, payload=None):
        for handler in self._subscribers.get(topic, []):
            try:
                handler(payload)
            except Exception as exc:  # subscriber fail ho toh bhi pipeline nahi rukegi
                print(f"[bus] subscriber error on '{topic}': {exc}")
