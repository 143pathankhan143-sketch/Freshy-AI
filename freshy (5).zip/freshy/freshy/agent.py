"""Freshy — Agent Engine: RUNTIME MASTER LOOP + MULTI-STEP PLANNER (Phase 1).

  PERCEIVE → IDENTIFY → ROUTE → CONTEXT/MEMORY
    → [ REASON → PLAN → SAFETY → EXECUTE → OBSERVE → VERIFY ] × N steps
    → STATE → MEMORY → RESPOND

Phase 1 upgrade: CORE path ab ek asli agent loop hai —
model tool call karta hai → safety check → execute → result wapas model
ko → agla step… jab tak jawab final na ho (ya max steps na ho).

Har stage audit log (Module 21) + event bus (Module 19) mein jaati hai.
"""
import json
import re

from .tools.builtin import safe_math

_MATH_CANDIDATE = re.compile(r"\d[\d\s.+\-*/^%()]*")


def _extract_math(text):
    """Message se math expression nikalo — '2^10 kitna hota hai?' → 1024."""
    for match in _MATH_CANDIDATE.finditer(text):
        candidate = match.group(0).strip().rstrip("+-*/^%").strip()
        if not candidate or not any(op in candidate for op in "+-*/^%"):
            continue
        try:
            value = safe_math(candidate)
            if isinstance(value, float) and value.is_integer():
                value = int(value)
            return candidate, value
        except Exception:
            continue
    return None


class AgentEngine:
    def __init__(self, app):
        self.app = app

    # ═══════════════ MASTER LOOP ═══════════════
    def handle(self, text, interactive=False):
        app = self.app
        text = (text or "").strip()
        if not text:
            return "Kuch likho na! 😄"

        # 1. PERCEIVE
        self.audit("perceive", {"input": text, "channel": "text"})
        app.bus.publish("user.message", {"text": text})

        # 2. IDENTIFY (Module 2/3 — Phase 3 mein voice)
        identity = app.identity.identify()
        self.audit("identify", {"user": identity.name, "trust": identity.trust, "source": identity.source})

        # 3. STATE: task start (Module 15)
        task_id = app.tasks.start(text)

        # 4. MEMORY: conversation save (Module 16)
        app.memory.save_message(app.session, "user", text)

        try:
            reply = self._route(text, interactive)
            app.tasks.finish(task_id, "done", reply[:300])
            self.audit("state", {"task_id": task_id, "status": "done"})
        except Exception as exc:
            self.audit("error", {"stage": "pipeline", "error": str(exc)})
            app.tasks.finish(task_id, "failed", str(exc))
            self.audit("state", {"task_id": task_id, "status": "failed"})
            reply = f"😵 Ek technical problem aa gayi ({exc}). Thodi der baad try karo."

        # 5. RESPOND (Module 22)
        reply = app.response.polish(reply)
        app.memory.save_message(app.session, "assistant", reply)
        self.audit("respond", {"reply": reply[:300]})
        app.bus.publish("assistant.reply", {"text": reply})
        return reply

    # ═══════════════ Module 27: Intelligent Request Router ═══════════════
    def _route(self, text, interactive):
        fast = self._fast_path(text)
        if fast is not None:
            self.audit("route", {"path": "FAST"})
            return fast
        self.audit("route", {"path": "AGENT"})
        return self._core_path(text, interactive)

    def _fast_path(self, text):
        """Chhote system commands — bina LLM ke direct tool."""
        low = text.lower()
        if len(low) <= 48:
            if re.search(r"\b(time|samay|baje)\b", low):
                return self._run_tool("time_now", {})
            if re.search(r"\b(date|tareekh)\b", low):
                return self._run_tool("date_today", {})
            if re.search(r"\b(battery|cpu|ram|disk|system)\b", low):
                return self._run_tool("system_stats", {})
        math = _extract_math(text)
        if math:
            return f"🧮 {math[0]} = {math[1]}"
        return None

    # ═══════════════ AGENT PATH: multi-step loop (Module 7 + 8) ═══════════════
    def _core_path(self, text, interactive):
        app = self.app

        # CONTEXT (Module 5) + MEMORY RETRIEVE (Module 16)
        context = app.context.build(text)
        self.audit("context", {
            "facts": len(context["relevant_facts"]),
            "history": len(context["recent_messages"]),
            "goals": len(context.get("goals", [])),
        })
        self.audit("memory.retrieve", {"facts": [f["key"] for f in context["relevant_facts"]]})

        messages = app.core.build_messages(text, context)
        tool_specs = app.registry.specs()
        steps_taken = []

        for step in range(app.config.max_steps):
            # REASON (Module 4 + 6: LLM, native function calling, fallback chain)
            response, provider = app.router.chat(messages, tool_specs)
            tool_calls = response.get("tool_calls") or []
            self.audit("reason", {
                "step": step + 1,
                "provider": provider,
                "tools": [t["name"] for t in tool_calls] or None,
            })

            # Koi tool call nahi → final jawab
            if not tool_calls:
                self.audit("plan", {"steps": steps_taken})
                final = (response.get("content") or "").strip()
                return final or "Hmm… jawab generate nahi hua — dobara try karo."

            # Assistant (tool_calls) message loop mein wapas
            messages.append(
                response.get("raw_message")
                or self._assistant_tool_message(response, tool_calls)
            )

            # Har tool call: SAFETY → EXECUTE → OBSERVE → VERIFY
            for call in tool_calls:
                name = str(call.get("name") or "")
                if not name:
                    continue
                args = call.get("args") if isinstance(call.get("args"), dict) else {}
                ok, result = self._run_tool_call(name, args, interactive)
                steps_taken.append(f"{name}→{'ok' if ok else 'fail'}")
                # result wapas model ko (Module 13 → observe)
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.get("id"),
                    "content": str(result)[:4000],
                })

        # MAX STEPS reached (Module 14 — verify partial)
        self.audit("plan", {"steps": steps_taken, "note": "max steps reached"})
        return (f"⚠️ Maine {app.config.max_steps} steps try kar liye. Jo hua: "
                + "; ".join(steps_taken)
                + ". Kaam ko chhote hisson mein todo, phir try karo.")

    def _run_tool_call(self, name, args, interactive):
        app = self.app
        # SAFETY GATE (Module 9) — har step mein, har tool pe
        decision = app.safety.check(name, args, app.registry)
        self.audit("safety", {"tool": name, "decision": decision.action})
        if decision.action == "BLOCK":
            return False, f"BLOCKED: {decision.reason}"
        if decision.action == "CONFIRM":
            allowed, why = app.safety.confirm(name, args, interactive)
            self.audit("safety", {"tool": name, "confirmed": allowed})
            if not allowed:
                return False, "DENIED: user confirmation nahi mili"
        # EXECUTE + VERIFY (Modules 12-14) with retry
        outcome = self._execute(name, args)
        if outcome["ok"]:
            return True, outcome["result"]
        return False, f"ERROR: {outcome['error']}"

    @staticmethod
    def _assistant_tool_message(response, tool_calls):
        """Mock/jab raw_message na ho — standard OpenAI format mein reconstruct."""
        return {
            "role": "assistant",
            "content": response.get("content") or None,
            "tool_calls": [
                {
                    "id": c.get("id"),
                    "type": "function",
                    "function": {
                        "name": c.get("name"),
                        "arguments": json.dumps(c.get("args") or {}, ensure_ascii=False),
                    },
                }
                for c in tool_calls
            ],
        }

    # ═══════════════ tool helpers ═══════════════
    def _run_tool(self, name, args, interactive=False):
        """Fast-path ke liye: safety + execute + human-readable format."""
        app = self.app
        decision = app.safety.check(name, args, app.registry)
        self.audit("safety", {"tool": name, "decision": decision.action})
        if decision.action == "BLOCK":
            return f"⛔ {decision.reason}"
        if decision.action == "CONFIRM":
            allowed, why = app.safety.confirm(name, args, interactive)
            if not allowed:
                return f"🚫 Confirmation nahi mili ({why}) — cancel."
        outcome = self._execute(name, args)
        if outcome["ok"]:
            return self._format(name, outcome["result"])
        return f"⚠️ {name} fail hua: {outcome['error']}"

    def _execute(self, name, args, retries=1):
        """Module 12 (execution) + 13 (observation) + 14 (verification) + retry."""
        app = self.app
        tool = app.registry.get(name)
        last_error = "unknown error"
        for attempt in range(retries + 1):
            self.audit("execute", {"tool": name, "args": args, "attempt": attempt})
            try:
                result = tool.run(args if isinstance(args, dict) else {})
                result = "" if result is None else str(result)
                self.audit("observe", {"tool": name, "result": result[:200]})
                if result.strip():
                    self.audit("verify", {"tool": name, "status": "PASS"})
                    app.bus.publish("tool.executed", {"tool": name, "ok": True})
                    return {"ok": True, "result": result}
                last_error = "tool ne empty result diya"
            except Exception as exc:
                last_error = str(exc)
                self.audit("observe", {"tool": name, "error": last_error[:200]})
        self.audit("verify", {"tool": name, "status": "FAIL", "error": last_error[:200]})
        app.bus.publish("tool.executed", {"tool": name, "ok": False})
        return {"ok": False, "error": last_error}

    _TOOL_TEMPLATES = {
        "time_now": "🕒 Abhi {r} baje hain.",
        "date_today": "📅 Aaj {r} hai.",
    }

    def _format(self, name, result):
        template = self._TOOL_TEMPLATES.get(name, "{r}")
        try:
            return template.format(r=result)
        except Exception:
            return str(result)

    # ---------- shorthand ----------
    def audit(self, stage, data):
        self.app.audit.log(stage, data)
