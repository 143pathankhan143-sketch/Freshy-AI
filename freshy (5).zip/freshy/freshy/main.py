"""FreshyApp — composition root: saare modules wire karta hai.

Ye file tumhare architecture diagram ka "wiring" hai —
har module apni jagah pe plug hota hai aur Agent Engine
(master loop) unhe orchestrate karta hai.
"""
import uuid

from .agent import AgentEngine
from .audit import Audit
from .brain.router import ModelRouter
from .bus import EventBus
from .config import Config
from .context import ContextManager
from .core import FreshyCore
from .goals import GoalManager
from .health import HealthMonitor
from .identity import IdentityEngine
from .memory.store import Memory
from .response import ResponseEngine
from .safety import SafetyGate
from .state import TaskManager
from .tools.android import is_termux
from .tools.builtin import build_registry


class FreshyApp:
    def __init__(self, verbose=False):
        self.session = uuid.uuid4().hex[:8]

        # Module 24 — Config & Secrets
        self.config = Config()

        # Module 19 — Event Bus
        self.bus = EventBus()

        # Module 21 — Audit
        self.audit = Audit(self.config.db_path, verbose=verbose)
        self.audit.session = self.session

        # Modules 4a/16 — Memory
        self.memory = Memory(self.config.db_path)

        # Module 4c — Goal Manager (Phase 1)
        self.goals = GoalManager(self.config.db_path)

        # Module 20 — Health
        self.health = HealthMonitor()

        # Modules 2/3 — Identity & Session
        self.identity = IdentityEngine(self.config)

        # Module 5 — Context
        self.context = ContextManager(self.config, self.memory, self.identity, self.goals)

        # Module 6 — Model Router (providers + fallback + native tools)
        self.router = ModelRouter(self.config, self.audit, self.health)

        # Modules 10/11 — Capability & Tool Registry (18 tools)
        self.registry = build_registry(self.config, self.memory, self.goals)

        # Module 9 — Safety Gate
        self.safety = SafetyGate(self.config, self.audit)

        # Module 4 — Freshy Core (system prompt + messages)
        self.core = FreshyCore(self.config, self.router)

        # Module 15 — State & Tasks
        self.tasks = TaskManager(self.config.db_path)

        # Module 22 — Response Engine
        self.response = ResponseEngine(self.config)

        # Module 8 — Agent Engine (MASTER LOOP, multi-step)
        self.agent = AgentEngine(self)

        # Event bus → audit bridge (har event trace mein)
        for topic in ("user.message", "assistant.reply", "tool.executed"):
            self.bus.subscribe(
                topic,
                lambda payload, t=topic: self.audit.log("bus", {"topic": t, "payload": payload}),
            )

    def handle(self, text, interactive=False):
        """Ek user request → poora master loop → reply."""
        return self.agent.handle(text, interactive)

    def status(self):
        return {
            "session": self.session,
            "environment": "termux" if is_termux() else "desktop",
            "providers": self.router.real_providers + ["mock (fallback)"],
            "mock_only": self.router.using_mock_only,
            "memory": self.memory.stats(),
            "goals": self.goals.stats(),
            "allowed_roots": self.config.allowed_roots,
            "gates": {
                "web": "on" if self.config.enable_web else "off",
                "code_run": "on" if self.config.allow_code else "off",
                "shell": "on" if self.config.allow_shell else "off",
                "max_agent_steps": self.config.max_steps,
            },
            "recent_tasks": self.tasks.recent(5),
            "capabilities": self.registry.capabilities(),
            "safety": {
                "policy": "low→ALLOW · medium→CONFIRM · high→CONFIRM(if enabled) · unknown/gated→BLOCK",
            },
            "health": self.health.snapshot(),
        }
