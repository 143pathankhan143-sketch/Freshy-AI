"""Freshy — Context Manager (Architecture Module 5).

Sab alag-alag context ko ek UNIFIED context mein merge karta hai:
user + temporal + device + conversation history + memory facts + goals.
"""
import datetime
import os
import platform
import shutil


class ContextManager:
    def __init__(self, config, memory, identity_engine, goal_manager=None):
        self.config = config
        self.memory = memory
        self.identity = identity_engine
        self.goals = goal_manager

    def build(self, user_message=None):
        now = datetime.datetime.now()
        return {
            "user": self.identity.identify().as_dict(),
            "time": now.strftime("%d %b %Y, %I:%M %p (%A)"),
            "recent_messages": self.memory.recent(6),
            "relevant_facts": (
                self.memory.search(user_message, limit=6)
                if user_message else self.memory.all_facts()[:8]
            ),
            "goals": (self.goals.active(5) if self.goals else []),
            "device": self.device_snapshot(),
        }

    @staticmethod
    def device_snapshot():
        info = {
            "os": f"{platform.system()} {platform.release()}",
            "machine": platform.machine(),
            "cpus": os.cpu_count() or "?",
        }
        try:
            usage = shutil.disk_usage(os.path.abspath(os.sep))
            info["disk_free_gb"] = round(usage.free / 2**30, 1)
        except Exception:
            pass
        if hasattr(os, "getloadavg"):
            try:
                info["load"] = round(os.getloadavg()[0], 2)
            except Exception:
                pass
        return info
