"""Freshy — Audit & History (Architecture Module 21).

Master loop ki HAR stage yahan record hoti hai — perceive se respond tak.
Jab kabhi kuch tootega, yahi trace debugging bachayega.

Table: freshy_data/freshy.db → audit(ts, session, stage, data)
"""
import datetime
import json
import sqlite3

STAGE_EMOJI = {
    "perceive": "🎤",
    "identify": "🪪",
    "route": "🔀",
    "context": "🧩",
    "memory.retrieve": "💾",
    "reason": "🧠",
    "plan": "📋",
    "safety": "🔐",
    "execute": "⚡",
    "observe": "👁️",
    "verify": "🔍",
    "recover": "🛟",
    "state": "🗃️",
    "respond": "💬",
    "error": "❗",
    "bus": "🚌",
    "provider.fallback": "♻️",
}


class Audit:
    def __init__(self, db_path, verbose=False):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS audit ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, session TEXT, stage TEXT, data TEXT)"
        )
        self.conn.commit()
        self.verbose = verbose
        self.session = "-"

    def log(self, stage, data):
        try:
            ts = datetime.datetime.now().isoformat(timespec="seconds")
            self.conn.execute(
                "INSERT INTO audit (ts, session, stage, data) VALUES (?, ?, ?, ?)",
                (ts, self.session, stage, json.dumps(data, default=str, ensure_ascii=False)),
            )
            self.conn.commit()
        except Exception:
            pass  # audit kabhi pipeline crash nahi karne dega
        if self.verbose:
            emoji = STAGE_EMOJI.get(stage, "•")
            try:
                print(f"   {emoji} {stage:<17} {json.dumps(data, default=str, ensure_ascii=False)[:150]}")
            except UnicodeEncodeError:
                print(f"   {stage:<17} (trace hidden on this console)")

    def recent(self, stage, n=3):
        """Kisi stage ke aakhri n entries (data dicts) — status/debug ke liye."""
        try:
            rows = self.conn.execute(
                "SELECT data FROM audit WHERE stage = ? ORDER BY id DESC LIMIT ?",
                (stage, n),
            ).fetchall()
            return [json.loads(r[0]) for r in rows]
        except Exception:
            return []
