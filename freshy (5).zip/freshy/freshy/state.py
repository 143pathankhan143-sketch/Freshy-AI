"""Freshy — State & Task Management (Architecture Module 15).

Har request ek task ban jaati hai: running → done/failed.
Phase 5 mein isi table pe checkpoint/crash-resume aayega.
"""
import datetime
import sqlite3


class TaskManager:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS tasks ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, goal TEXT, status TEXT, result TEXT)"
        )
        self.conn.commit()

    def start(self, goal):
        cursor = self.conn.execute(
            "INSERT INTO tasks (ts, goal, status, result) VALUES (?, ?, ?, ?)",
            (datetime.datetime.now().isoformat(timespec="seconds"), str(goal)[:300], "running", ""),
        )
        self.conn.commit()
        return cursor.lastrowid

    def finish(self, task_id, status, result=""):
        self.conn.execute(
            "UPDATE tasks SET status = ?, result = ? WHERE id = ?",
            (status, str(result)[:500], task_id),
        )
        self.conn.commit()

    def recent(self, n=5):
        rows = self.conn.execute(
            "SELECT id, ts, goal, status FROM tasks ORDER BY id DESC LIMIT ?", (n,)
        ).fetchall()
        return [{"id": r[0], "ts": r[1], "goal": r[2], "status": r[3]} for r in reversed(rows)]
