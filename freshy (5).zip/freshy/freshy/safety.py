"""Freshy — Safety & Permission Gate (Architecture Module 9).

HAR tool call se pehle ye gate chalta hai (multi-step loop mein bhi):

  1. Tool registry mein hai?        nahi → ❌ BLOCK
  2. Tool ka precheck() pass?       nahi → ❌ BLOCK  (config gates, path rules,
                                     secret-file guard, web on/off)
  3. risk_for(args) kya hai?
       low    → ✅ ALLOW
       medium → ⚠️ CONFIRM  (dynamic: file overwrite, browser open…)
       high   → ⚠️ CONFIRM  (shell, code_run — agar enabled hain)
"""


class Decision:
    def __init__(self, action, reason):
        self.action = action  # ALLOW | CONFIRM | BLOCK
        self.reason = reason


class SafetyGate:
    def __init__(self, config, audit):
        self.config = config
        self.audit = audit

    def check(self, tool_name, args, registry):
        tool = registry.get(tool_name)
        if tool is None:
            return Decision("BLOCK", f"Unknown tool '{tool_name}' — registry mein nahi hai")
        if not isinstance(args, dict):
            args = {}
        ok, reason = tool.precheck(args)  # Module 11: tool validation
        if not ok:
            return Decision("BLOCK", reason)
        risk = tool.risk_for(args)        # Module 9: risk classification
        if risk == "low":
            return Decision("ALLOW", "low-risk tool")
        if risk == "medium":
            return Decision("CONFIRM", f"'{tool_name}' medium-risk hai — user confirmation chahiye")
        return Decision("CONFIRM", f"'{tool_name}' HIGH-RISK action hai — explicit confirmation chahiye")

    def confirm(self, tool_name, args, interactive):
        """User se poochho. Non-interactive mode = auto-deny (safe side)."""
        if not interactive:
            return False, "non-interactive mode — auto-cancel (safety first)"
        try:
            answer = input(f"⚠️  Freshy '{tool_name}' tool use karna chahta hai (args: {args}). Allow? [y/N] ")
        except (EOFError, KeyboardInterrupt):
            return False, "input interrupt — cancel"
        allowed = answer.strip().lower() in ("y", "yes")
        return allowed, "user ne allow kiya" if allowed else "user ne deny kiya"
