"""Freshy — Web Tools (Phase 1): bina kisi API key ke internet access.

  web_search → DuckDuckGo HTML (GET, phir POST try) → fallback Wikipedia API
  web_fetch  → URL laakar HTML ko clean text mein convert karta hai

Sab kuch Python standard library se — koi dependency nahi.
Agar FRESHY_ENABLE_WEB=0 toh safety gate dono ko block kar dega.
"""
import json
import re
import urllib.parse
import urllib.request
from html import unescape
from html.parser import HTMLParser

from .base import Tool

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")


def _http_get(url, timeout=12, max_bytes=1_500_000, data=None):
    headers = {"User-Agent": _UA, "Accept-Language": "en,hi;q=0.8"}
    request = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read(max_bytes).decode("utf-8", "ignore")


def _strip_tags(fragment):
    text = re.sub(r"<[^>]+>", " ", fragment or "")
    text = unescape(unescape(text))  # DDG kabhi double-escape karta hai (&amp;nbsp;)
    return re.sub(r"\s+", " ", text).strip()


# ─────────────────── DuckDuckGo HTML search ───────────────────
def _ddg_search(query, limit=5):
    """Pehle GET, fail ho toh POST (classic html endpoint)."""
    html = ""
    errors = []
    for attempt in (
        lambda: _http_get("https://html.duckduckgo.com/html/?q=" + urllib.parse.quote_plus(query)),
        lambda: _http_get(
            "https://html.duckduckgo.com/html/",
            data=urllib.parse.urlencode({"q": query}).encode("utf-8"),
        ),
    ):
        try:
            html = attempt()
            if "result__a" in html:
                break
        except Exception as exc:
            errors.append(str(exc))
    if "result__a" not in html:
        raise RuntimeError("DDG nahi mila: " + "; ".join(e[:80] for e in errors[:2]))

    results = []
    anchors = re.findall(r"<a([^>]*result__a[^>]*)>(.*?)</a>", html, re.S)
    snippets = re.findall(r"<a[^>]*result__snippet[^>]*>(.*?)</a>", html, re.S)
    for i, (attrs, title_html) in enumerate(anchors[:limit]):
        href_match = re.search(r'href="([^"]+)"', attrs)
        if not href_match:
            continue
        url = href_match.group(1)
        uddg = re.search(r"[?&]uddg=([^&]+)", url)
        if uddg:
            url = urllib.parse.unquote(uddg.group(1))
        if url.startswith("//"):
            url = "https:" + url
        title = _strip_tags(title_html)
        snippet = _strip_tags(snippets[i]) if i < len(snippets) else ""
        if title:
            results.append((title, url, snippet))
    return results


# ─────────────────── Wikipedia fallback ───────────────────
def _wikipedia_search(query, limit=5):
    lang = "hi" if re.search(r"[\u0900-\u097F]", query) else "en"
    url = (
        f"https://{lang}.wikipedia.org/w/api.php?action=query&list=search"
        f"&format=json&srlimit={limit}&srsearch=" + urllib.parse.quote_plus(query)
    )
    data = json.loads(_http_get(url))
    results = []
    for item in data.get("query", {}).get("search", []):
        title = item.get("title", "")
        snippet = _strip_tags(item.get("snippet", ""))
        link = f"https://{lang}.wikipedia.org/wiki/" + urllib.parse.quote(title.replace(" ", "_"))
        if title:
            results.append((title, link, snippet))
    return results


# ─────────────────── HTML → text ───────────────────
class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript", "head"):
            self._skip += 1

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript", "head") and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if not self._skip and data.strip():
            self.parts.append(data.strip())


def _html_to_text(html):
    title_match = re.search(r"<title[^>]*>(.*?)</title>", html, re.S | re.I)
    title = _strip_tags(title_match.group(1)) if title_match else ""
    extractor = _TextExtractor()
    try:
        extractor.feed(html)
    except Exception:
        pass
    return title, re.sub(r"\s+", " ", " ".join(extractor.parts)).strip()


# ─────────────────── Tools ───────────────────
class WebSearchTool(Tool):
    name = "web_search"
    description = "Internet pe search karta hai (DuckDuckGo; offline/block ho toh Wikipedia)"
    parameters = {
        "type": "object",
        "properties": {"query": {"type": "string"}, "max_results": {"type": "integer"}},
        "required": ["query"],
    }
    risk = "low"

    def __init__(self, config):
        self.config = config

    def precheck(self, args):
        if not self.config.enable_web:
            return False, "web tools disabled hain (FRESHY_ENABLE_WEB=0)"
        return True, "ok"

    def run(self, args):
        query = str(args.get("query", "")).strip()
        if not query:
            raise ValueError("query chahiye")
        limit = 5
        try:
            limit = max(1, min(8, int(args.get("max_results", 5))))
        except (TypeError, ValueError):
            pass
        results = []
        source = ""
        try:
            results = _ddg_search(query, limit)
            source = "DuckDuckGo"
        except Exception:
            try:
                results = _wikipedia_search(query, limit)
                source = "Wikipedia"
            except Exception as exc:
                raise RuntimeError(f"search fail: {exc}")
        if not results:
            return f"'{query}' pe kuch nahi mila 🤷"
        lines = [f"🔎 {len(results)} results ({source}):"]
        for i, (title, url, snippet) in enumerate(results, 1):
            lines.append(f"{i}. {title}\n   {url}\n   {snippet[:160]}")
        return "\n".join(lines)


class WebFetchTool(Tool):
    name = "web_fetch"
    description = "Ek URL ka content laakar clean text mein deta hai (articles, docs pages)"
    parameters = {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}
    risk = "low"

    def __init__(self, config):
        self.config = config

    def precheck(self, args):
        if not self.config.enable_web:
            return False, "web tools disabled hain (FRESHY_ENABLE_WEB=0)"
        return True, "ok"

    def run(self, args):
        url = str(args.get("url", "")).strip()
        if not re.match(r"^https?://", url, re.I):
            raise ValueError("sirf http/https URLs")
        raw = _http_get(url, timeout=15)
        if "<html" in raw[:2000].lower() or "<body" in raw[:5000].lower():
            title, text = _html_to_text(raw)
            header = f"📄 {title}\n" if title else ""
            body = text[:3500]
            if len(text) > 3500:
                body += " …(truncated)"
            return header + body if body else "(page khaali lagti hai)"
        return raw[:3500]
