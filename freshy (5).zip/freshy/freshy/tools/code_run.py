"""Freshy — Code Run Tool (Phase 1): sandbox-lite code execution (Module 12).

Python code ko isolated subprocess mein run karta hai:
  - alag process (main runtime crash nahi hoga)
  - `-I` isolated mode (user site-packages import nahi honge)
  - timeout (default 15s) + output truncation
  - secrets wale env vars (API keys) child process ko kabhi nahi jaate (Module 24)

HONEST NOTE: ye "sandbox-lite" hai — Docker/firejail-grade security nahi.
True isolation Phase 5 (hardening) mein aayegi. Isliye ye tool:
  - default DISABLED hai (FRESHY_ALLOW_CODE=1 se enable)
  - HIGH risk → har run pe user confirmation
"""
import os
import shutil
import subprocess
import sys
import uuid

from .base import Tool


class CodeRunTool(Tool):
    name = "code_run"
    description = "Python code run karta hai (isolated process + timeout). Output wapas deta hai."
    parameters = {"type": "object", "properties": {"code": {"type": "string"}}, "required": ["code"]}
    risk = "high"

    def __init__(self, config):
        self.config = config

    def precheck(self, args):
        if not self.config.allow_code:
            return False, "code_run disabled hai (FRESHY_ALLOW_CODE=1 se enable hota hai — soch samajh kar)"
        return True, "ok"

    def run(self, args):
        code = str(args.get("code", "")).strip()
        if not code:
            raise ValueError("code chahiye")
        sandbox_root = os.path.join(self.config.data_dir, "sandbox")
        workdir = os.path.join(sandbox_root, uuid.uuid4().hex[:10])
        os.makedirs(workdir, exist_ok=True)
        script = os.path.join(workdir, "script.py")
        with open(script, "w", encoding="utf-8") as fh:
            fh.write(code)
        # Secrets kabhi child process mein nahi jaayenge
        clean_env = {
            k: v for k, v in os.environ.items()
            if not any(s in k.upper() for s in ("KEY", "TOKEN", "SECRET", "PASSWORD"))
        }
        timeout = self.config.code_timeout
        try:
            proc = subprocess.run(
                [sys.executable, "-I", script],
                capture_output=True, text=True, timeout=timeout, cwd=workdir, env=clean_env,
            )
            output = (proc.stdout or "").strip()
            if proc.stderr:
                output += ("\n[stderr] " + proc.stderr.strip())
            output = output.strip() or "(no output)"
            return f"🐍 exit={proc.returncode}\n{output[:2500]}"
        except subprocess.TimeoutExpired:
            return f"⏰ {timeout}s ka timeout ho gaya — code infinite loop mein lagta hai"
        finally:
            shutil.rmtree(workdir, ignore_errors=True)
