"""Freshy — File Tools (Phase 1) with PERMISSION MAP.

Architecture Module 9 ka "File Access Rules":
  - sirf ALLOWED ROOTS ke andar access (FRESHY_ALLOWED_ROOTS, default: project folder)
  - .env jaisi secrets files pe hard block (Module 25)
  - overwrite = medium risk (confirmation), naya file = low risk
"""
import os

from .base import Tool

_SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "sandbox", ".mypy_cache"}


def resolve_path(path, roots):
    """Path resolve + guard. Returns (full_path, allowed: bool)."""
    raw = str(path or "").strip()
    if not raw:
        return "", False
    expanded = os.path.expanduser(raw)
    if not os.path.isabs(expanded) and roots:
        expanded = os.path.join(roots[0], expanded)
    full = os.path.realpath(expanded)
    for root in roots:
        root_real = os.path.realpath(root)
        if full == root_real or full.startswith(root_real + os.sep):
            return full, True
    return full, False


def is_secret_file(path):
    return os.path.basename(str(path)) == ".env"


class _FileTool(Tool):
    def __init__(self, config):
        self.config = config

    def _resolve(self, path):
        return resolve_path(path, self.config.allowed_roots)

    def _precheck_path(self, args, need_path=True):
        path = str(args.get("path", "") or "").strip()
        if need_path and not path:
            return False, "path chahiye"
        if path:
            full, allowed = self._resolve(path)
            if not allowed:
                roots = ", ".join(self.config.allowed_roots)
                return False, f"path allowed roots ke bahar hai ({full}). Allowed: {roots}"
            if is_secret_file(full):
                return False, "secrets file (.env) access blocked hai"
        return True, "ok"


class FileListTool(_FileTool):
    name = "file_list"
    description = "Allowed folder ke files/folders list karta hai"
    parameters = {
        "type": "object",
        "properties": {"path": {"type": "string", "description": "optional — default allowed root"}},
        "required": [],
    }
    risk = "low"

    def precheck(self, args):
        return self._precheck_path(args, need_path=False)

    def run(self, args):
        target = str(args.get("path", "") or "").strip()
        if target:
            base, allowed = self._resolve(target)
        else:
            base = os.path.realpath(self.config.allowed_roots[0])
        if not os.path.isdir(base):
            raise FileNotFoundError(f"folder nahi mila: {base}")
        entries = []
        try:
            for entry in sorted(os.scandir(base), key=lambda e: (not e.is_dir(), e.name.lower())):
                if entry.name.startswith(".") and entry.name not in (".", ".."):
                    continue
                if entry.is_dir():
                    entries.append(f"📁 {entry.name}/")
                else:
                    size = entry.stat().st_size
                    size_h = f"{size/1024:.1f} KB" if size < 1024 * 1024 else f"{size/2**20:.1f} MB"
                    entries.append(f"📄 {entry.name} ({size_h})")
                if len(entries) >= 60:
                    entries.append("… (aur bhi hain)")
                    break
        except OSError as exc:
            raise RuntimeError(f"list nahi kar paya: {exc}")
        return "\n".join(entries) or "(khaali folder)"


class FileReadTool(_FileTool):
    name = "file_read"
    description = "Ek text file ka content padhta hai (allowed roots ke andar)"
    parameters = {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}
    risk = "low"

    def precheck(self, args):
        return self._precheck_path(args)

    def run(self, args):
        full, _ = self._resolve(args.get("path", ""))
        if not os.path.exists(full):
            raise FileNotFoundError(f"file nahi mili: {args.get('path')}")
        if os.path.isdir(full):
            raise IsADirectoryError("ye folder hai, file nahi — file_list use karo")
        if os.path.getsize(full) > 200_000:
            raise ValueError("file bahut badi hai (200KB+)")
        try:
            with open(full, encoding="utf-8", errors="strict") as fh:
                content = fh.read(6000)
        except UnicodeDecodeError:
            return "📎 ye binary file hai — text read nahi ho sakti"
        return content if content.strip() else "(file khaali hai)"


class FileWriteTool(_FileTool):
    name = "file_write"
    description = "File likhta hai / banata hai (allowed roots ke andar). Overwrite pe confirmation maangta hai."
    parameters = {
        "type": "object",
        "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
        "required": ["path", "content"],
    }
    risk = "low"

    def precheck(self, args):
        return self._precheck_path(args)

    def risk_for(self, args):
        """DYNAMIC RISK: naya file = low, existing file overwrite = medium."""
        full, allowed = self._resolve(args.get("path", ""))
        if allowed and os.path.exists(full):
            return "medium"
        return "low"

    def run(self, args):
        content = str(args.get("content", ""))
        if not str(args.get("path", "")).strip():
            raise ValueError("path chahiye")
        full, _ = self._resolve(args.get("path", ""))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(content)
        return f"💾 likh diya: {args.get('path')} ({len(content)} chars)"


class FileSearchTool(_FileTool):
    name = "file_search"
    description = "Files ke andar text search karta hai (grep jaisa, allowed roots mein)"
    parameters = {
        "type": "object",
        "properties": {"query": {"type": "string"}, "path": {"type": "string"}},
        "required": ["query"],
    }
    risk = "low"

    def precheck(self, args):
        return self._precheck_path(args, need_path=False)

    def run(self, args):
        query = str(args.get("query", "")).strip()
        if not query:
            raise ValueError("query chahiye")
        target = str(args.get("path", "") or "").strip()
        base = self._resolve(target)[0] if target else os.path.realpath(self.config.allowed_roots[0])
        if not os.path.isdir(base):
            raise FileNotFoundError(f"folder nahi mila: {target}")
        matches, scanned = [], 0
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS and not d.startswith(".")]
            for filename in filenames:
                if scanned >= 300 or len(matches) >= 15:
                    break
                fpath = os.path.join(dirpath, filename)
                scanned += 1
                try:
                    if os.path.getsize(fpath) > 200_000:
                        continue
                    with open(fpath, encoding="utf-8", errors="ignore") as fh:
                        for lineno, line in enumerate(fh, 1):
                            if query.lower() in line.lower():
                                rel = os.path.relpath(fpath, base)
                                matches.append(f"{rel}:{lineno}: {line.strip()[:120]}")
                                if len(matches) >= 15:
                                    break
                except OSError:
                    continue
            if len(matches) >= 15:
                break
        if not matches:
            return f"'{query}' kuch bhi nahi mila ({scanned} files scan hui)"
        return f"🔎 {len(matches)} matches ({scanned} files scan hui):\n" + "\n".join(matches)
