"""Freshy — Capability & Tool Registry (Architecture Modules 10 & 11).

Phase 1: har tool ke paas ab JSON-Schema parameters bhi hain —
native function calling ke liye. Plus:

  - precheck(args)  → safety gate tool VALIDATION ke liye use karta hai
                      (config gates, path rules, secret-file guard)
  - risk_for(args)  → DYNAMIC risk classification
                      (e.g. naya file likhna = low, overwrite = medium)
"""


class Tool:
    name = "tool"
    description = ""
    risk = "low"  # low | medium | high
    parameters = {"type": "object", "properties": {}, "required": []}

    def precheck(self, args):
        """Safety gate ye pehle chalata hai — tool validation (Module 11).
        Returns: (ok: bool, reason: str)"""
        return True, "ok"

    def risk_for(self, args):
        """Dynamic risk classification (Module 9 — Risk Classification)."""
        return self.risk

    def run(self, args):
        raise NotImplementedError

    def to_spec(self):
        """OpenAI-compatible function-calling spec (native tools)."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


class ToolRegistry:
    def __init__(self):
        self._tools = {}

    def register(self, tool):
        self._tools[tool.name] = tool

    def get(self, name):
        return self._tools.get(name)

    def names(self):
        return list(self._tools)

    def specs(self):
        """Native function-calling specs — saare tools ke."""
        return [t.to_spec() for t in self._tools.values()]

    def capabilities(self):
        """Module 10: WHAT can Freshy do?"""
        return [
            {"name": t.name, "risk": t.risk, "available": True}
            for t in self._tools.values()
        ]

    def for_prompt(self):
        return "\n".join(
            f"- {t.name}: {t.description} | args: {t.parameters}"
            for t in self._tools.values()
        )
