"""Freshy — Built-in Tools (Architecture Modules 10-12).

Phase 1: sab tools ab JSON-Schema parameters ke saath — native
function calling ke liye. Registry mein 18 tools hain:

  system   : time_now, date_today, math_eval, system_stats
  memory   : remember, recall
  files    : file_list, file_read, file_write, file_search (permission map)
  web      : web_search, web_fetch (bina API key)
  goals    : goal_add, goal_list, goal_update
  exec     : code_run (sandbox-lite), shell (default disabled)
  ui       : open_url
"""
import ast
import datetime
import operator
import os
import platform
import re
import shutil
import subprocess
import webbrowser

from .base import Tool, ToolRegistry
from .code_run import CodeRunTool
from .files import FileListTool, FileReadTool, FileSearchTool, FileWriteTool
from .web import WebFetchTool, WebSearchTool

# ← goal tools (freshy/goals.py)
from ..goals import GoalAddTool, GoalListTool, GoalUpdateTool

# ← Android/Termux tools (sirf mobile pe register hote hain)
from .android import ANDROID_TOOLS, battery_status, is_termux

# ---------- safe math (koi function/name access nahi) ----------
_BIN_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod, ast.Pow: operator.pow,
}
_UNARY_OPS = {ast.USub: operator.neg, ast.UAdd: operator.pos}


def safe_math(expr):
    """Safely evaluate a pure-math expression via AST whitelist."""
    if not expr or len(expr) > 200:
        raise ValueError("expression invalid ya too long")
    expr = expr.replace("^", "**")

    def ev(node):
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OPS:
            left, right = ev(node.left), ev(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 1000:
                raise ValueError("exponent too big")
            return _BIN_OPS[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPS:
            return _UNARY_OPS[type(node.op)](ev(node.operand))
        raise ValueError(f"unsupported expression: {type(node).__name__}")

    return ev(ast.parse(expr, mode="eval").body)


def _pretty_num(value):
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


# ---------- system tools ----------
class TimeNowTool(Tool):
    name = "time_now"
    description = "Current time batata hai"
    parameters = {"type": "object", "properties": {}, "required": []}
    risk = "low"

    def run(self, args):
        return datetime.datetime.now().strftime("%I:%M %p")


class DateTodayTool(Tool):
    name = "date_today"
    description = "Aaj ki date batata hai"
    parameters = {"type": "object", "properties": {}, "required": []}
    risk = "low"

    def run(self, args):
        return datetime.datetime.now().strftime("%d %B %Y (%A)")


class MathTool(Tool):
    name = "math_eval"
    description = "Math expression calculate karta hai, e.g. (2+3)*7"
    parameters = {"type": "object", "properties": {"expr": {"type": "string"}}, "required": ["expr"]}
    risk = "low"

    def run(self, args):
        expr = str(args.get("expr", "")).strip()
        if not expr:
            raise ValueError("expr chahiye")
        result = _pretty_num(safe_math(expr))
        return f"🧮 {expr} = {result}"


class SystemStatsTool(Tool):
    name = "system_stats"
    description = "Is device ka snapshot — OS, CPU, disk, battery, load"
    parameters = {"type": "object", "properties": {}, "required": []}
    risk = "low"

    def run(self, args):
        lines = [
            f"🖥️  OS: {platform.system()} {platform.release()} ({platform.machine()})",
            f"⚙️  CPU cores: {os.cpu_count() or '?'}",
        ]
        try:
            usage = shutil.disk_usage(os.path.abspath(os.sep))
            lines.append(f"💾 Disk: {round(usage.free / 2**30)} GB free / {round(usage.total / 2**30)} GB")
        except Exception:
            pass
        if hasattr(os, "getloadavg"):
            try:
                lines.append(f"⚖️  Load avg: {round(os.getloadavg()[0], 2)}")
            except Exception:
                pass
        try:
            import psutil  # optional dependency
            battery = psutil.sensors_battery()
            if battery:
                state = "charging" if battery.power_plugged else "on battery"
                lines.append(f"🔋 Battery: {round(battery.percent)}% ({state})")
        except Exception:
            lines.append("🔋 Battery: (psutil install karo — optional)")
        return "\n".join(lines)


# ---------- memory tools ----------
class RememberTool(Tool):
    """Module 16: long-term memory about the user."""
    name = "remember"
    description = "User ke baare mein ek fact yaad rakhta hai (long-term memory)"
    parameters = {
        "type": "object",
        "properties": {"key": {"type": "string"}, "value": {"type": "string"}},
        "required": ["key", "value"],
    }
    risk = "low"

    def __init__(self, memory):
        self.memory = memory

    def run(self, args):
        key = str(args.get("key", "")).strip()
        value = str(args.get("value", "")).strip()
        if not key or not value:
            raise ValueError("key aur value dono chahiye")
        self.memory.save_fact(key, value)
        return f"💾 Memory mein save: {key} → {value}"


class RecallTool(Tool):
    name = "recall"
    description = "User ke baare mein yaad rakhe facts search karta hai"
    parameters = {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}
    risk = "low"

    def __init__(self, memory):
        self.memory = memory

    def run(self, args):
        query = str(args.get("query", ""))
        results = self.memory.search(query, limit=5)
        if not results:
            return "Kuch khaas yaad nahi mila 🤷"
        return "🔎 " + " | ".join(f"{r['key']} → {r['value']}" for r in results)


# ---------- UI tool ----------
class OpenUrlTool(Tool):
    name = "open_url"
    description = "Browser mein ek URL kholta hai"
    parameters = {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}
    risk = "low"  # user ne kaha: URL seedha kholo, permission mat maango

    def run(self, args):
        url = str(args.get("url", "")).strip()
        if not re.match(r"^https?://", url, re.IGNORECASE):
            raise ValueError("sirf http/https URLs allowed hain")
        if is_termux():
            # Android: termux-open-url → am start (abs path) → am start (PATH)
            details = []
            for command in (["termux-open-url", url],
                            ["/system/bin/am", "start", "-a", "android.intent.action.VIEW", "-d", url],
                            ["am", "start", "-a", "android.intent.action.VIEW", "-d", url]):
                try:
                    proc = subprocess.run(command, capture_output=True, text=True, timeout=10)
                    if proc.returncode == 0:
                        return f"🌐 Khol diya: {url}"
                    details.append(f"{command[0].split('/')[-1]}: {(proc.stderr or proc.stdout or '').strip()[:80]}")
                except (OSError, subprocess.TimeoutExpired) as exc:
                    details.append(f"{command[0].split('/')[-1]}: {str(exc)[:60]}")
            if not webbrowser.open(url):
                raise RuntimeError(f"URL nahi khul payi ({url}): {'; '.join(details)}")
            return f"🌐 Khol diya: {url}"
        if not webbrowser.open(url):
            raise RuntimeError(f"URL nahi khul payi ({url}) — koi browser nahi mila")
        return f"🌐 Khol diya: {url}"


# ---------- shell (default disabled — precheck gate) ----------
class ShellTool(Tool):
    name = "shell"
    description = "System shell command run karta hai (output wapas deta hai)"
    parameters = {"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]}
    risk = "high"

    def __init__(self, config):
        self.config = config

    def precheck(self, args):
        if not self.config.allow_shell:
            return False, "Shell tool disabled hai (FRESHY_ALLOW_SHELL=1 se enable hota hai)"
        return True, "ok"

    def run(self, args):
        command = str(args.get("command", "")).strip()
        if not command:
            raise ValueError("command chahiye")
        proc = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=20)
        output = proc.stdout or ""
        if proc.stderr:
            output += "\n[stderr] " + proc.stderr
        output = output.strip() or "(no output)"
        return f"$ {command}\n{output[:2000]}"


# ---------- registry builder ----------
def build_registry(config, memory, goals):
    registry = ToolRegistry()
    for tool in (
        # system
        TimeNowTool(), DateTodayTool(), MathTool(), SystemStatsTool(),
        # memory
        RememberTool(memory), RecallTool(memory),
        # ui
        OpenUrlTool(),
        # files (permission map ke saath)
        FileListTool(config), FileReadTool(config), FileWriteTool(config), FileSearchTool(config),
        # web (bina API key)
        WebSearchTool(config), WebFetchTool(config),
        # goals (Module 4c)
        GoalAddTool(goals), GoalListTool(goals), GoalUpdateTool(goals),
        # exec (default disabled — precheck gated)
        CodeRunTool(config), ShellTool(config),
    ):
        registry.register(tool)
    # Android actions (Module 10) — sirf Termux pe register hote hain
    if is_termux():
        for tool in ANDROID_TOOLS:
            registry.register(tool)
    return registry
