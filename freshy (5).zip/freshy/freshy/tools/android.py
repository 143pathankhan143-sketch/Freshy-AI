"""Freshy — Android/Termux Tools (Architecture Module 10: "Android Actions").

Sirf Termux (Android) pe register hote hain — desktop pe registry
mein aate hi nahi (Capability Registry: AVAILABLE only on mobile).

  open_app       — app kholo (bina Termux:API ke bhi chalta hai)
  notify         — phone pe notification (Termux:API chahiye)
  clipboard_get  — clipboard padho (Termux:API)
  clipboard_set  — clipboard pe copy karo (Termux:API)

Termux:API = F-Droid se "Termux:API" app + `pkg install termux-api`
"""
import json
import os
import re
import subprocess

from .base import Tool

# Common apps (mock brain + LLM hint ke liye)
COMMON_APP_PACKAGES = {
    "whatsapp": "com.whatsapp",
    "instagram": "com.instagram.android",
    "insta": "com.instagram.android",
    "youtube": "com.google.android.youtube",
    "yt": "com.google.android.youtube",
    "chrome": "com.android.chrome",
    "telegram": "org.telegram.messenger",
    "gmail": "com.google.android.gm",
    "maps": "com.google.android.apps.maps",
    "spotify": "com.spotify.music",
    "paytm": "net.one97.paytm",
    "gpay": "com.google.android.apps.nbu.paisa.user",
    "phonepe": "com.phonepe.app",
    "settings": "com.android.settings",
    "playstore": "com.android.vending",
}


def is_termux():
    """Termux environment detect (TERMUX_VERSION / PREFIX env vars)."""
    return ("TERMUX_VERSION" in os.environ
            or "com.termux" in os.environ.get("PREFIX", ""))


def battery_status():
    """Battery (percent, status) — /sys se (no deps) ya termux-battery-status se.
    Desktop pe (None, "") return karta hai."""
    try:
        with open("/sys/class/power_supply/battery/capacity") as fh:
            percent = int(fh.read().strip())
        status = ""
        try:
            with open("/sys/class/power_supply/battery/status") as fh:
                status = fh.read().strip().lower()
        except OSError:
            pass
        return percent, status
    except (OSError, ValueError):
        pass
    try:
        proc = subprocess.run(["termux-battery-status"],
                              capture_output=True, text=True, timeout=8)
        data = json.loads(proc.stdout or "{}")
        return data.get("percentage"), str(data.get("status", "")).lower()
    except Exception:
        return None, ""


# common app naam → Android package (sirf stable packages — OEM wale
# (dialer, camera, messages) search khud dhoondh leta hai)
APP_ALIASES = {
    "whatsapp": "com.whatsapp", "wa": "com.whatsapp",
    "youtube": "com.google.android.youtube", "yt": "com.google.android.youtube",
    "instagram": "com.instagram.android", "insta": "com.instagram.android",
    "facebook": "com.facebook.katana", "fb": "com.facebook.katana",
    "chrome": "com.android.chrome", "browser": "com.android.chrome",
    "gmail": "com.google.android.gm", "mail": "com.google.android.gm",
    "maps": "com.google.android.apps.maps", "google maps": "com.google.android.apps.maps",
    "playstore": "com.android.vending", "play store": "com.android.vending",
    "settings": "com.android.settings",
    "telegram": "org.telegram.messenger",
    "snapchat": "com.snapchat.android",
    "twitter": "com.twitter.android", "x": "com.twitter.android",
    "linkedin": "com.linkedin.android",
    "reddit": "com.reddit.frontpage",
    "spotify": "com.spotify.music",
    "amazon": "in.amazon.mShop.android.shopping",
    "flipkart": "com.flipkart.android",
    "myntra": "com.myntra.android",
    "paytm": "net.one97.paytm",
    "phonepe": "com.phonepe.app",
    "gpay": "com.google.android.apps.nbu.paisa.user",
    "google pay": "com.google.android.apps.nbu.paisa.user",
    "zomato": "com.application.zomato",
    "swiggy": "in.swiggy.android",
    "uber": "com.ubercab",
    "ola": "com.olacabs.customer",
    "hotstar": "in.startv.hotstar", "jiohotstar": "in.startv.hotstar",
}

_PACKAGE_RE = re.compile(r"^[a-zA-Z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$")


class OpenAppTool(Tool):
    name = "open_app"
    description = ("Phone pe app kholta hai. 'package' mein app ka COMMON NAAM "
                   "(whatsapp, youtube, instagram, paytm, chrome...) ya exact "
                   "Android package (com.whatsapp) — dono chalega. "
                   "Pehle common naam try karo, package name sirf zaroorat ho toh.")
    parameters = {
        "type": "object",
        "properties": {
            "package": {"type": "string",
                        "description": "App ka naam (whatsapp, youtube, paytm) ya package (com.whatsapp)"},
        },
        "required": ["package"],
    }
    risk = "low"

    def run(self, args):
        raw = str(args.get("package", "")).strip().strip("`").strip(chr(39))
        package = self._resolve(raw)
        details = []
        # Method 0 (sabse reliable): intent-URI launch — activity naam ki
        # zaroorat NahI, system khud launcher resolve karta hai. Naye Android
        # pe cmd/monkey block ho sakte hain — ye tarika wahan bhi chalta hai.
        intent_uri = ("intent:#Intent;action=android.intent.action.MAIN;"
                      f"category=android.intent.category.LAUNCHER;package={package};end")
        for am_path in ("/system/bin/am", "am"):
            try:
                proc = subprocess.run([am_path, "start", "-d", intent_uri],
                                      capture_output=True, text=True, timeout=10)
                if proc.returncode == 0 or "Starting:" in (proc.stdout or ""):
                    return f"📱 App khol diya: {package}"
                details.append(f"am: {(proc.stderr or proc.stdout or '').strip()[:100]}")
            except (OSError, subprocess.TimeoutExpired) as exc:
                details.append(f"am: {str(exc)[:80]}")
        # Method 1: cmd resolve-activity + am start (real binaries — Termux-safe)
        try:
            resolve = subprocess.run(
                ["/system/bin/cmd", "package", "resolve-activity", "--brief",
                 "-c", "android.intent.category.LAUNCHER", package],
                capture_output=True, text=True, timeout=15)
            activities = [l.strip() for l in (resolve.stdout or "").splitlines() if "/" in l]
            if not activities:
                details.append(
                    f"resolve: {(resolve.stderr or 'launcher activity nahi mili').strip()[:100]}")
            else:
                proc = subprocess.run(["/system/bin/am", "start", "-n", activities[-1]],
                                      capture_output=True, text=True, timeout=10)
                if proc.returncode == 0 or "Starting:" in (proc.stdout or ""):
                    return f"📱 App khol diya: {package}"
                details.append(f"am: {(proc.stderr or proc.stdout or '').strip()[:100]}")
        except (OSError, subprocess.TimeoutExpired) as exc:
            details.append(f"cmd: {str(exc)[:80]}")
        # Method 2: monkey (Android pe SCRIPT hai — sh ke through chalega)
        try:
            proc = subprocess.run(
                ["sh", "-c",
                 f"/system/bin/monkey --pct-syskeys 0 -p {package} -c android.intent.category.LAUNCHER 1"],
                capture_output=True, text=True, timeout=15)
            if proc.returncode == 0:
                return f"📱 App khol diya: {package}"
            details.append(f"monkey: {(proc.stderr or proc.stdout or '').strip()[:100]}")
        except (OSError, subprocess.TimeoutExpired) as exc:
            details.append(f"monkey: {str(exc)[:80]}")
        raise RuntimeError(
            f"app ({package}) nahi khul payi — shayad installed nahi hai. "
            f"Termux mein check karo: `pm list packages | grep {package.split('.')[-1]}` "
            f"({'; '.join(details[:2])})")

    def _resolve(self, name):
        """naam → package: (1) exact package (2) common aliases (3) installed search"""
        if _PACKAGE_RE.match(name):
            return name
        low = name.lower().strip()
        if low in APP_ALIASES:
            return APP_ALIASES[low]
        if is_termux():
            try:
                proc = subprocess.run(["pm", "list", "packages"],
                                      capture_output=True, text=True, timeout=20)
                keyword = low.replace(" ", "")
                matches = [l.replace("package:", "").strip()
                           for l in (proc.stdout or "").splitlines()
                           if keyword in l.lower()]
                if len(matches) == 1:
                    return matches[0]
                if len(matches) > 1:
                    raise ValueError(
                        f"'{name}' ke liye {len(matches)} apps mili — ek chuno: "
                        + ", ".join(matches[:6]))
            except (OSError, subprocess.TimeoutExpired):
                pass
        raise ValueError(
            f"app '{name}' nahi mili — common naam try karo (whatsapp, youtube, "
            "chrome) ya exact package name batao (jaise com.whatsapp)")


class NotifyTool(Tool):
    name = "notify"
    description = "Phone pe notification bhejta hai (title + text)"
    parameters = {
        "type": "object",
        "properties": {"title": {"type": "string"}, "text": {"type": "string"}},
        "required": ["text"],
    }
    risk = "low"

    def run(self, args):
        text = str(args.get("text", "")).strip()
        if not text:
            raise ValueError("text chahiye")
        title = str(args.get("title", "") or "Freshy").strip()
        try:
            proc = subprocess.run(
                ["termux-notification", "--title", title, "--content", text],
                capture_output=True, text=True, timeout=10)
        except FileNotFoundError:
            raise RuntimeError("Termux:API chahiye — F-Droid se 'Termux:API' app "
                               "install karo + Termux mein `pkg install termux-api`")
        if proc.returncode != 0:
            raise RuntimeError(f"notification fail: {(proc.stderr or '')[:100]}")
        return f"🔔 Notification bhej di: {title}"


class ClipboardGetTool(Tool):
    name = "clipboard_get"
    description = "Phone ka clipboard content padhta hai"
    parameters = {"type": "object", "properties": {}, "required": []}
    risk = "low"

    def run(self, args):
        try:
            proc = subprocess.run(["termux-clipboard-get"],
                                  capture_output=True, text=True, timeout=10)
        except FileNotFoundError:
            raise RuntimeError("Termux:API chahiye — F-Droid se 'Termux:API' app "
                               "install karo + Termux mein `pkg install termux-api`")
        content = (proc.stdout or "").strip()
        return f"📋 Clipboard: {content[:500]}" if content else "📋 Clipboard khaali hai"


class ClipboardSetTool(Tool):
    name = "clipboard_set"
    description = "Phone ke clipboard pe text copy karta hai"
    parameters = {
        "type": "object",
        "properties": {"text": {"type": "string"}},
        "required": ["text"],
    }
    risk = "low"

    def run(self, args):
        text = str(args.get("text", ""))
        if not text.strip():
            raise ValueError("text chahiye")
        try:
            subprocess.run(["termux-clipboard-set"], input=text, text=True,
                           capture_output=True, timeout=10)
        except FileNotFoundError:
            raise RuntimeError("Termux:API chahiye — F-Droid se 'Termux:API' app "
                               "install karo + Termux mein `pkg install termux-api`")
        return f"📋 Clipboard pe copy ho gaya: {text[:100]}"


ANDROID_TOOLS = (OpenAppTool(), NotifyTool(), ClipboardGetTool(), ClipboardSetTool())
