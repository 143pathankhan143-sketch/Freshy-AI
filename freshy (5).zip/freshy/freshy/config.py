"""Freshy — Configuration & Secrets Manager (Architecture Module 24).

Sab kuch ek jagah: API keys (.env / environment se), user preferences,
safety policy, provider settings, file-access permission map.

RULE: Secrets kabhi code, logs ya UI mein nahi likhe jaate —
sirf environment / .env se aate hain. (Module 25 ka promise.)

Phase 1 additions: allowed roots, code/shell/web gates, max steps.
"""
import os

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Ek hi OpenAI-compatible client se ye sab providers chal jaate hain
# Model chains: pehla = default, baaki = AUTOMATIC fallback
# NOTE (Aug 2026): Groq ne llama-3.3-70b-versatile + llama-3.1-8b-instant
# band kar diye — official replacement: openai/gpt-oss-120b.
# Live list dekhne ke liye: `python run.py models`
PROVIDERS = {
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "models": ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.6-27b"],
        "key_env": "GROQ_API_KEY",
    },
    "openrouter": {
        "base_url": "https://openrouter.ai/api/v1",
        "models": ["openrouter/auto", "openai/gpt-oss-120b", "google/gemini-2.5-flash"],
        "key_env": "OPENROUTER_API_KEY",
    },
    "gemini": {
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "models": ["gemini-flash-latest", "gemini-2.5-flash", "gemini-2.0-flash"],
        "key_env": "GEMINI_API_KEY",
    },
}


class Config:
    def __init__(self, root_dir=ROOT_DIR):
        self.root = root_dir
        self._load_dotenv(os.path.join(self.root, ".env"))
        self.data_dir = os.path.join(self.root, "freshy_data")
        os.makedirs(self.data_dir, exist_ok=True)

    # ---------- .env loading ----------
    def _load_dotenv(self, path):
        """Simple .env parser — python-dotenv dependency ki zaroorat nahi.

        Handles: '=' ke around spaces, quoted values, aur INLINE comments:
        "GROQ_API_KEY=gsk_xxx  # comment" → value sirf 'gsk_xxx' hogi.
        """
        if not os.path.exists(path):
            return
        try:
            with open(path, encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
                        value = value[1:-1]  # quoted value → as-is
                    else:
                        value = value.split(" #")[0].strip()  # inline comment hatao
                    if key and value and key not in os.environ:
                        os.environ[key] = value
        except OSError:
            pass

    def get(self, key, default=None):
        return os.environ.get(key, default)

    # ---------- persona (Modules 4 / 22) ----------
    @property
    def user_name(self):
        return self.get("FRESHY_USER_NAME", "Boss")

    @property
    def language(self):
        return self.get("FRESHY_LANG", "hinglish").lower()  # hinglish | english | hindi

    @property
    def style(self):
        return self.get("FRESHY_STYLE", "normal").lower()   # concise | normal | detailed

    # ---------- safety policy (Module 9) ----------
    @property
    def allow_shell(self):
        return self.get("FRESHY_ALLOW_SHELL", "0") == "1"

    @property
    def allow_code(self):
        return self.get("FRESHY_ALLOW_CODE", "0") == "1"

    @property
    def enable_web(self):
        return self.get("FRESHY_ENABLE_WEB", "1") == "1"

    @property
    def max_steps(self):
        """Multi-step agent loop ki limit (Module 7 — planner)."""
        try:
            return max(1, int(self.get("FRESHY_MAX_STEPS", "6")))
        except ValueError:
            return 6

    @property
    def code_timeout(self):
        try:
            return max(5, int(self.get("FRESHY_CODE_TIMEOUT", "15")))
        except ValueError:
            return 15

    # ---------- file access permission map (Module 9 — File Access Rules) ----------
    @property
    def allowed_roots(self):
        raw = self.get("FRESHY_ALLOWED_ROOTS", "")
        if raw.strip():
            roots = [os.path.abspath(os.path.expanduser(p.strip())) for p in raw.split(",") if p.strip()]
            if roots:
                return roots
        return [self.root]  # default: sirf Freshy ka project folder

    # ---------- providers (Module 6) ----------
    def provider_order(self):
        """Jin providers ki key set hai, priority order mein."""
        raw = self.get("FRESHY_PROVIDER_ORDER", "groq,openrouter,gemini")
        order = [p.strip().lower() for p in raw.split(",") if p.strip()]
        return [p for p in order if p in PROVIDERS and self.get(PROVIDERS[p]["key_env"])]

    def models_for(self, name):
        """Model fallback chain — user override top priority ke saath."""
        defaults = PROVIDERS[name]["models"]
        override = self.get(f"FRESHY_MODEL_{name.upper()}", "").strip()
        if override:
            return [override] + [m for m in defaults if m != override]
        return list(defaults)

    # ---------- storage ----------
    @property
    def db_path(self):
        return os.path.join(self.data_dir, "freshy.db")
