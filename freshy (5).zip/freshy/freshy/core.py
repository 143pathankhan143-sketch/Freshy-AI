"""Freshy — Freshy Core (Architecture Module 4).

Phase 1: system prompt + messages builder. Native function calling
ke saath tool protocol ki zaroorat nahi — router hi specs pass karta hai.
Multi-step LOOP Agent Engine mein hai (agent.py).
"""
_LANGUAGES = {
    "hinglish": "Hinglish (Roman Hindi + English mix, natural conversational tone)",
    "english": "English",
    "hindi": "Hindi (Devanagari script)",
}


class FreshyCore:
    def __init__(self, config, router):
        self.config = config
        self.router = router

    def build_messages(self, user_text, context):
        """System prompt (persona+context+goals+facts) + history + user message."""
        return (
            [{"role": "system", "content": self._system_prompt(context)}]
            + [dict(m) for m in context.get("recent_messages", [])]
            + [{"role": "user", "content": user_text}]
        )

    def _system_prompt(self, context):
        config = self.config
        facts = "; ".join(
            f"{f['key']} → {f['value']}" for f in context.get("relevant_facts", [])
        ) or "(abhi kuch yaad nahi)"
        goals = "\n".join(
            f"  #{g['id']} [P{g['priority']}] {g['goal']}"
            + (f" (deadline: {g['deadline']})" if g.get("deadline") else "")
            for g in context.get("goals", [])
        ) or "  (koi active goal nahi)"
        device = context.get("device", {})
        roots = ", ".join(config.allowed_roots)

        return f"""You are Freshy — {config.user_name} ka personal AI assistant. Warm, sharp, thoda witty.

CONTEXT:
- Current date/time: {context.get('time')}
- Device: {device.get('os', '?')} · {device.get('cpus', '?')} CPU cores
- Facts you remember about the user: {facts}
- User's active goals:
{goals}
- File access allowed ONLY in: {roots}

RULES:
- Reply language: {self._lang_line()}. Reply style: {config.style} (concise = 1-2 lines).
- Tumhare paas tools hain (function calling) — jab kaam ho sake tab use karo, warna seedha jawab do.
- Multi-step kaam mein ek-ek tool use karo, result dekho, phir aage badho (max {config.max_steps} steps).
- File operations sirf allowed roots ke andar — bahar ki path safety gate block kar dega.
- Web search/fetch ke jawab mein source URL zaroor mention karo.
- Koi tool fail ho jaye toh user ko honestly batao — jhoothe claims mat karo.
- Numbers/dates verify karke bolo; guess mat karo."""

    def _lang_line(self):
        return _LANGUAGES.get(self.config.language, _LANGUAGES["hinglish"])
