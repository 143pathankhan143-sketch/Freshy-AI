"""Freshy — Response Engine (Architecture Module 22).

LLM ke jawab ko user ki style preference ke hisaab se polish karta hai
(concise / normal). Voice engine (Module 23, Phase 2) isi output ko bolega.
"""
import re


class ResponseEngine:
    def __init__(self, config):
        self.config = config

    def polish(self, text):
        text = (text or "").strip()
        if not text:
            text = "Hmm… kuch bolna bhool gaya. Dobara puchna?"
        if self.config.style == "concise":
            sentences = re.split(r"(?<=[.!?।])\s+", text)
            if len(sentences) > 2:
                text = " ".join(sentences[:2])
        return text
