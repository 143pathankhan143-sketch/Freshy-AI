"""Freshy — Memory (Architecture Modules 4a & 16).

Messages (conversation) + Facts (long-term memory about the user).
Storage: local SQLite (privacy — data device se bahar nahi jaata).

Phase 0: keyword search. Phase 4 upgrade: embeddings + vector search.
"""
import datetime
import re
import sqlite3


class Memory:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.conn.executescript(
            "CREATE TABLE IF NOT EXISTS messages ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, session TEXT, role TEXT, content TEXT);"
            "CREATE TABLE IF NOT EXISTS facts ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, key TEXT UNIQUE, value TEXT, importance INTEGER DEFAULT 3);"
        )
        self.conn.commit()

    # ---------- conversation memory (working / short-term) ----------
    def save_message(self, session, role, content):
        self.conn.execute(
            "INSERT INTO messages (ts, session, role, content) VALUES (?, ?, ?, ?)",
            (datetime.datetime.now().isoformat(timespec="seconds"), session, role, str(content)[:4000]),
        )
        self.conn.commit()

    def recent(self, n=6):
        rows = self.conn.execute(
            "SELECT role, content FROM messages ORDER BY id DESC LIMIT ?", (n,)
        ).fetchall()
        return [{"role": r[0], "content": r[1]} for r in reversed(rows)]

    # ---------- facts (long-term, Module 16) ----------
    def save_fact(self, key, value, importance=3):
        self.conn.execute("DELETE FROM facts WHERE key = ?", (key,))
        self.conn.execute(
            "INSERT INTO facts (ts, key, value, importance) VALUES (?, ?, ?, ?)",
            (datetime.datetime.now().isoformat(timespec="seconds"),
             str(key).strip()[:100], str(value).strip()[:1000], importance),
        )
        self.conn.commit()

    def search(self, query, limit=5):
        """Phase 0: keyword scoring. (Phase 4: semantic / vector search.)"""
        tokens = [t for t in re.split(r"\W+", (query or "").lower()) if len(t) > 2]
        if not tokens:
            return []
        rows = self.conn.execute("SELECT key, value FROM facts").fetchall()
        scored = []
        for key, value in rows:
            hay = f"{key} {value}".lower()
            score = sum(1 for t in tokens if t in hay)
            if score > 0:
                scored.append((score, key, value))
        scored.sort(key=lambda item: -item[0])
        return [{"key": k, "value": v} for _, k, v in scored[:limit]]

    def all_facts(self):
        rows = self.conn.execute("SELECT key, value FROM facts ORDER BY id DESC LIMIT 20").fetchall()
        return [{"key": k, "value": v} for k, v in rows]

    def stats(self):
        messages = self.conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        facts = self.conn.execute("SELECT COUNT(*) FROM facts").fetchone()[0]
        return {"messages": messages, "facts": facts}
