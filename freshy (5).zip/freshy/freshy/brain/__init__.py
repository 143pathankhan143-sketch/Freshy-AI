"""Freshy AI brain package (Module 4b + 6)."""
