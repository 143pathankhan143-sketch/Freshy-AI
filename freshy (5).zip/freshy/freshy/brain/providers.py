"""Freshy — AI Brain providers (Architecture Module 4b).

Phase 1: NATIVE FUNCTION CALLING — tools OpenAI-compatible
`tools` parameter se jaate hain, aur model `tool_calls` mein
wapas bhejta hai. (Phase 0 ka custom JSON protocol khatam.)

  Groq / OpenRouter / Gemini — sab same OpenAI-compatible format
  MockProvider               — offline emulation (demo + fallback)
"""
import json
import re
import urllib.error
import urllib.request

from ..tools.android import COMMON_APP_PACKAGES


class Provider:
    name = "base"

    def chat(self, messages, tools=None):
        """messages + optional tool specs →
        {"content": str, "tool_calls": [{"id", "name", "args"}], "raw_message": dict}"""
        raise NotImplementedError


class OpenAICompatProvider(Provider):
    def __init__(self, name, base_url, api_key, models, timeout=35):
        self.name = name
        self.base_url = base_url
        self.api_key = api_key
        self.models = list(models) or ["default"]
        self.current_model = self.models[0]
        self.timeout = timeout

    def chat(self, messages, tools=None):
        return self._request(self.current_model, messages, tools)

    def try_model(self, model, messages, tools=None):
        """Fallback chain ke liye — success pe model sticky ho jaata hai."""
        response = self._request(model, messages, tools)
        self.current_model = model
        return response

    def _request(self, model, messages, tools=None):
        url = self.base_url.rstrip("/") + "/chat/completions"
        payload = {
            "model": model,
            "messages": messages,
            "temperature": 0.4,
            "max_tokens": 1000,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                # UA zaroori hai: Cloudflare "Python-urllib" ko bot maan ke
                # 403 error code 1010 se block kar deta hai (Groq pe dekha)
                "User-Agent": "Freshy/0.3.4",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", "ignore")[:300]
            except Exception:
                pass
            raise RuntimeError(f"HTTP {exc.code}: {detail or exc.reason}") from exc
        message = data["choices"][0]["message"]
        content = message.get("content") or ""
        if not content.strip() and message.get("reasoning"):
            content = str(message["reasoning"])  # gpt-oss jaise reasoning models
        tool_calls = []
        for call in message.get("tool_calls") or []:
            function = call.get("function") or {}
            try:
                call_args = json.loads(function.get("arguments") or "{}")
            except (json.JSONDecodeError, ValueError):
                call_args = {}
            if not isinstance(call_args, dict):
                call_args = {"input": str(call_args)}
            tool_calls.append({
                "id": call.get("id") or "call_1",
                "name": function.get("name") or "",
                "args": call_args,
            })
        return {
            "content": content,
            "tool_calls": tool_calls,
            "raw_message": message,  # loop mein as-is wapas jaata hai (provider-faithful)
        }

    def list_models(self):
        """Provider ke live models (GET /models) — `run.py models` ke liye."""
        url = self.base_url.rstrip("/") + "/models"
        request = urllib.request.Request(
            url, headers={"Authorization": f"Bearer {self.api_key}",
                          "User-Agent": "Freshy/0.3.4"})
        with urllib.request.urlopen(request, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))
        ids = []
        for item in data.get("data", []):
            model_id = str(item.get("id", "?"))
            if model_id.startswith("models/"):  # Gemini "models/xyz" prefix
                model_id = model_id[len("models/"):]
            ids.append(model_id)
        return sorted(ids)


class MockProvider(Provider):
    """Bina API key ka dimaag — offline dev, demos, aur last-resort fallback.

    Native function calling EMULATE karta hai: tool call decide karta hai,
    aur tool results milne pe final jawab deta hai — taaki poora
    multi-step pipeline bina internet ke test ho sake.
    """
    name = "mock"

    def chat(self, messages, tools=None):
        # tool results aa chuke hain? → final answer mode
        tool_messages = [m for m in messages if m.get("role") == "tool"]
        if tool_messages:
            return {"content": self._after_tools(tool_messages), "tool_calls": [], "raw_message": None}

        last_user = ""
        for m in reversed(messages):
            if m["role"] == "user":
                last_user = m["content"]
                break
        low = last_user.lower()

        if tools:
            # Kaun se tools registered hain? (Android tools sirf Termux pe hote hain)
            available = set()
            for spec in tools:
                function = spec.get("function") or {}
                tool_name = function.get("name") or spec.get("name")
                if tool_name:
                    available.add(tool_name)
            call = self._maybe_tool(last_user, low, available)
            if call:
                return {"content": "", "tool_calls": [call], "raw_message": None}

        return {"content": self._reply_text(last_user, low), "tool_calls": [], "raw_message": None}

    # ---------- final answer after tools ran ----------
    def _after_tools(self, tool_messages):
        contents = [str(m.get("content") or "") for m in tool_messages]
        joined = " · ".join(c for c in contents if c)[:700]
        first = contents[0] if contents else ""
        if first.startswith("BLOCKED"):
            return f"⛔ Ye action main nahi le paya — safety gate ne block kiya: {first[8:].strip()}"
        if first.startswith("DENIED"):
            return "🚫 User confirmation nahi mili — cancel kar diya. (Interactive chat mode mein main pehle poochta hoon.)"
        if first.startswith("ERROR"):
            return f"😔 Tool fail ho gaya: {first[6:].strip()}"
        return f"Ho gaya! 👉 {joined}"

    # ---------- plain replies ----------
    def _reply_text(self, text, low):
        if re.search(r"\b(kaun ho|who are you|tumhara naam|your name)\b", low):
            return ("Main Freshy hoon — ek personal AI assistant 🧠 (abhi MOCK brain mode mein). "
                    ".env mein GROQ_API_KEY ya GEMINI_API_KEY daal do, phir main asli LLM se "
                    "sochkar jawab dunga — native function calling ke saath!")
        if re.search(r"\b(kaise ho|how are you|kya haal)\b", low):
            return "Main ekdum mast hoon! Tum batao — aaj kya karna hai?"
        if re.search(r"\b(hi|hello|hey|namaste|namaskar|salaam|hola)\b", low):
            return "Namastey! 👋 Main Freshy hoon — tumhara personal AI assistant. Bolo, kya madad karu?"
        if re.search(r"\b(thanks|thank you|shukriya|dhanyawad)\b", low):
            return "Arre koi baat nahi! Aur kuch chahiye toh bolo 😊"
        return (f'Samajh gaya: "{text[:70]}" — main abhi MOCK brain se jawab de raha hoon '
                "(real LLM fail hua ya key missing — error upar screen pe aaya hoga, "
                "ya `python run.py status` mein Provider health dekho). "
                "Tools (files, goals, web, time/date/math) abhi bhi poore kaam karte hain!")

    # ---------- tool decisions (offline demo ke liye) ----------
    def _maybe_tool(self, text, low, available):
        # 1) URL fetch/open?
        url_match = re.search(r"https?://[^\s]+", text)
        if url_match and re.search(r"\b(fetch|khol\s?ke|kholkar|kholo|open|page|website|site|url)\b", low):
            return {"id": "call_mock_1", "name": "web_fetch",
                    "args": {"url": url_match.group(0).rstrip(".,?!")}}

        # 2) web search?
        search = re.search(r"\b(?:search|google|dhundo|khojo)\b\s*(?:karo|kar|kijiye|for)?\s*:?\s*(.+)$", text, re.I)
        if search and search.group(1).strip():
            return {"id": "call_mock_1", "name": "web_search",
                    "args": {"query": search.group(1).strip()}}

        # 3) remember?
        remember = re.search(r"yaad\s+rakh\w*\s*(?:ki|karo\s+ki|lena\s+ki)?\s*[:,]?\s*(.+)", text, re.I)
        if remember:
            content = remember.group(1).strip().rstrip(".?!")
            if content:
                key = "naam" if "naam" in content.lower() else ("pasand" if "pasand" in content.lower() else "note")
                return {"id": "call_mock_1", "name": "remember",
                        "args": {"key": key, "value": content}}

        # 4) recall?
        if re.search(r"(kya\s+pasand|mujhe\s+kya|kya\s+yaad|recall)", low):
            return {"id": "call_mock_1", "name": "recall", "args": {"query": text}}

        # 4a) app open? ("whatsapp kholo" / "youtube kholo") — sirf Termux
        if "open_app" in available:
            app = re.search(r"([a-z]+)\s+(?:app\s+)?kholo", low)
            if app:
                package = COMMON_APP_PACKAGES.get(app.group(1))
                if package:
                    return {"id": "call_mock_1", "name": "open_app",
                            "args": {"package": package}}

        # 4b) notification? — sirf Termux
        if "notify" in available:
            notif = re.search(r"notification\s*(?:bhejo|bhej|do|dijiye)?\s*:?\s*(.*)", low)
            if notif:
                message = notif.group(1).strip() or "Freshy se hello! 👋"
                return {"id": "call_mock_1", "name": "notify",
                        "args": {"title": "Freshy", "text": message}}

        # 4c) clipboard? — sirf Termux
        if "clipboard" in low and ("clipboard_get" in available or "clipboard_set" in available):
            if re.search(r"\bkya\b|dikhao|read|padho", low) or not re.search(r"(copy|set|daalo|rakho)", low):
                if "clipboard_get" in available:
                    return {"id": "call_mock_1", "name": "clipboard_get", "args": {}}
            else:
                clip = re.search(r"clipboard\s*(?:pe|me|mein)?\s*(?:copy|set|daalo|rakho)\w*\s*(?:karo|kar)?\s*:?\s*(.*)", low)
                content = clip.group(1).strip() if clip else ""
                if content and "clipboard_set" in available:
                    return {"id": "call_mock_1", "name": "clipboard_set",
                            "args": {"text": content}}

        # 5) goal add?
        goal = re.search(r"(?:naya\s+goal\s+banao|naya\s+goal|goal\s+banao|goal\s+add|add\s+goal)\s*:?\s*(.+)", text, re.I)
        if goal:
            content = goal.group(1).strip()
            priority = 3
            pm = re.search(r"priority\s*(\d)", content, re.I)
            if pm:
                try:
                    priority = max(1, min(5, int(pm.group(1))))
                except ValueError:
                    pass
                content = re.sub(r",?\s*priority\s*\d", "", content, flags=re.I).strip()
            if content:
                return {"id": "call_mock_1", "name": "goal_add",
                        "args": {"goal": content, "priority": priority}}

        # 6) goal update? ("goal 1 complete kar do" / "goal 2 progress 50%")
        update = re.search(
            r"goals?\s*(\d+)\s*(?:ko\s*)?(complete|done|khatam|archiv\w*|progress\s*(\d+))", low)
        if update:
            gid = int(update.group(1))
            verb = update.group(2)
            percent = update.group(3)
            if percent:
                return {"id": "call_mock_1", "name": "goal_update",
                        "args": {"goal_id": gid, "progress": int(percent)}}
            status = "archived" if verb.startswith("archiv") else "done"
            return {"id": "call_mock_1", "name": "goal_update",
                    "args": {"goal_id": gid, "status": status}}

        # 7) goal list?
        if re.search(r"goals?\s+(dikhao|list|batao|dikha)|mere\s+goals", low):
            return {"id": "call_mock_1", "name": "goal_list", "args": {}}

        # 8) file tools? (filename detect karke)
        fname = re.search(r"[\w\-./\\]+\.[A-Za-z0-9]{1,5}", text)
        if fname:
            path = fname.group(0)
            if re.search(r"\b(banao|likho|write|create|save)\b", low):
                content_match = re.search(r"likho\s*:?\s*(.+)$", text, re.I)
                content = content_match.group(1).strip() if content_match else "Freshy note"
                return {"id": "call_mock_1", "name": "file_write",
                        "args": {"path": path, "content": content}}
            if re.search(r"\b(kya\s+likha|padho|read|kholo|dikhao)\b", low):
                return {"id": "call_mock_1", "name": "file_read", "args": {"path": path}}

        # 9) file list?
        if re.search(r"files?\s+(dikhao|list|batao)|folder\s+dikhao|directory\s+dikhao", low):
            return {"id": "call_mock_1", "name": "file_list", "args": {}}

        # 10) code run?
        code = re.search(r"\b(?:code|python|script)\s+chalao\b\s*:?\s*(.*)", low)
        if code and code.group(1).strip():
            return {"id": "call_mock_1", "name": "code_run", "args": {"code": code.group(1).strip()}}

        # 11) shell?
        shell = re.search(r"(?:shell|terminal|command)\s+chalao\s*:?\s*(.+)$", low)
        if shell:
            return {"id": "call_mock_1", "name": "shell", "args": {"command": shell.group(1).strip()}}

        return None
