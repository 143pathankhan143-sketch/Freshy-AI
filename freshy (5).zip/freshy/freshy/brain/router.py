"""Freshy — AI Orchestration Engine / Model Router (Architecture Module 6).

Har request pe: best available provider, fail hone pe AUTOMATIC FALLBACK.
Ab DO fallback layers hain:

  1. MODEL fallback:     model band ho jaye (decommissioned/deprecated)
                         toh usi provider ke alternate models auto-try hote hain
  2. PROVIDER fallback:  Groq → OpenRouter → Gemini → Mock

(Groq ne Aug 2026 mein llama-3.3-70b-versatile band kiya tha —
isi tarah ke breaks ab Freshy khud handle karta hai.)
"""
from ..config import PROVIDERS
import time

from .providers import MockProvider, OpenAICompatProvider

# Model band/deprecated hone wale errors (Groq/OpenRouter/Gemini common markers)
_MODEL_ERROR_MARKERS = (
    "model_decommissioned", "model_not_found", "decommissioned",
    "does not exist", "not a valid model", "invalid model",
    "has been deprecated", "no longer supported",
)


def _is_model_error(error_text):
    low = str(error_text).lower()
    return any(marker in low for marker in _MODEL_ERROR_MARKERS)


def _warn(text):
    """CLI warning — unicode-safe (Termux/Windows consoles)."""
    try:
        print(text)
    except UnicodeEncodeError:
        print(text.encode("ascii", "replace").decode())


class ModelRouter:
    def __init__(self, config, audit, health):
        self.audit = audit
        self.health = health
        self._warned = set()  # provider-wise one-time warnings (per session)
        self.chain = []
        for name in config.provider_order():
            spec = PROVIDERS[name]
            api_key = config.get(spec["key_env"])
            if api_key:
                self.chain.append(
                    OpenAICompatProvider(name, spec["base_url"], api_key, config.models_for(name))
                )
        self.real_providers = [p.name for p in self.chain]
        self.mock = MockProvider()
        self.chain.append(self.mock)  # last resort — hamesha chalega

    @property
    def using_mock_only(self):
        return len(self.real_providers) == 0

    def _chat_with_retry(self, provider, messages, tools):
        """429 (rate limit) aaye toh 2.5s ruk ke EK baar retry —
        per-minute wali limit khul jaati hai, daily quota pe nahi chalega."""
        try:
            return provider.chat(messages, tools)
        except Exception as exc:
            if "429" in str(exc):
                time.sleep(2.5)
                return provider.chat(messages, tools)
            raise

    def chat(self, messages, tools=None):
        """Chain mein se pehla working provider jawab dega.
        Returns: ({"content", "tool_calls", "raw_message"}, provider_name)"""
        errors = []
        for provider in self.chain:
            try:
                output = self._chat_with_retry(provider, messages, tools)
                self.health.record(provider.name, True)
                return output, provider.name
            except Exception as exc:
                # ── MODEL fallback: model band hai toh alternates try karo ──
                if _is_model_error(str(exc)) and hasattr(provider, "try_model"):
                    for alt_model in provider.models:
                        if alt_model == provider.current_model:
                            continue
                        try:
                            output = provider.try_model(alt_model, messages, tools)
                            self.health.record(provider.name, True, f"switched → {alt_model}")
                            self.audit.log("provider.model_switch", {
                                "provider": provider.name,
                                "model": alt_model,
                            })
                            return output, provider.name
                        except Exception as exc2:
                            errors.append(f"{provider.name}/{alt_model}: {str(exc2)[:100]}")
                # ── PROVIDER fallback: agla provider ──
                self.health.record(provider.name, False, str(exc))
                self.audit.log("provider.fallback", {
                    "provider": provider.name,
                    "error": str(exc)[:160],
                })
                errors.append(f"{provider.name}/{provider.current_model}: {str(exc)[:120]}")
                # VISIBILITY: mock pe chupchap girne ki jagah user ko batao
                # (ek provider = ek warning per session — spam nahi)
                if self.real_providers and provider.name not in self._warned:
                    self._warned.add(provider.name)
                    _warn(f"⚠️  {provider.name} fail: {str(exc)[:100]}")
                    _warn(f"    → next provider pe try kar raha hoon (details: python run.py status)")
        raise RuntimeError("sab providers fail ho gaye: " + " | ".join(errors))
