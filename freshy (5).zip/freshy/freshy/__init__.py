"""Freshy — Personal AI Assistant Runtime.

Phase 0: The Spine — master loop, event bus, memory, tools, safety, audit.
Phase 1: Real Brain & Real Tools — native function calling, multi-step
agent loop, file tools (permission map), web tools (no API key),
goal manager, code sandbox-lite.
Mobile Ready (0.3.0): Android/Termux edition — open_app, notify,
clipboard tools + battery/storage detection.
Desktop: 18 tools · Termux: 22 tools.
0.3.1: Groq ke Aug-2026 llama deprecations ka fix — naye default models
(openai/gpt-oss-120b), AUTO model-fallback chain, `run.py models` command.
"""

__version__ = "0.3.7"
