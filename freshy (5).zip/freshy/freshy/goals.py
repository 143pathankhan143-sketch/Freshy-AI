"""Freshy — Goal Manager (Architecture Module 4c — Phase 1 implement).

Goals, priorities (1=urgent … 5=low), deadlines, progress (0-100),
status (active/done/archived). Context engine active goals ko har
request mein LLM ko dikhata hai — isliye Freshy goals "yaad" rakhta hai.
"""
import datetime
import sqlite3

from .tools.base import Tool


def _now():
    return datetime.datetime.now().isoformat(timespec="seconds")


class GoalManager:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS goals ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, goal TEXT, "
            "priority INTEGER DEFAULT 3, deadline TEXT DEFAULT '', "
            "status TEXT DEFAULT 'active', progress INTEGER DEFAULT 0)"
        )
        self.conn.commit()

    def add(self, goal, priority=3, deadline=""):
        try:
            priority = max(1, min(5, int(priority)))
        except (TypeError, ValueError):
            priority = 3
        cursor = self.conn.execute(
            "INSERT INTO goals (ts, goal, priority, deadline) VALUES (?, ?, ?, ?)",
            (_now(), str(goal)[:300], priority, str(deadline or "")[:60]),
        )
        self.conn.commit()
        return cursor.lastrowid

    def update(self, goal_id, status=None, progress=None):
        row = self.conn.execute("SELECT id FROM goals WHERE id = ?", (goal_id,)).fetchone()
        if not row:
            return False
        if status is not None:
            if status not in ("active", "done", "archived"):
                raise ValueError("status sirf: active | done | archived")
            self.conn.execute("UPDATE goals SET status = ? WHERE id = ?", (status, goal_id))
        if progress is not None:
            try:
                progress = max(0, min(100, int(progress)))
                self.conn.execute("UPDATE goals SET progress = ? WHERE id = ?", (progress, goal_id))
            except (TypeError, ValueError):
                pass
        self.conn.commit()
        return True

    def active(self, limit=10):
        rows = self.conn.execute(
            "SELECT id, goal, priority, deadline, progress FROM goals "
            "WHERE status = 'active' ORDER BY priority ASC, id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {"id": r[0], "goal": r[1], "priority": r[2], "deadline": r[3], "progress": r[4]}
            for r in rows
        ]

    def all_recent(self, limit=15):
        rows = self.conn.execute(
            "SELECT id, goal, priority, deadline, status, progress FROM goals "
            "ORDER BY (status = 'active') DESC, priority ASC, id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {"id": r[0], "goal": r[1], "priority": r[2], "deadline": r[3], "status": r[4], "progress": r[5]}
            for r in rows
        ]

    def stats(self):
        active = self.conn.execute("SELECT COUNT(*) FROM goals WHERE status='active'").fetchone()[0]
        done = self.conn.execute("SELECT COUNT(*) FROM goals WHERE status='done'").fetchone()[0]
        return {"active": active, "done": done}


# ─────────────── Goal tools (native function calling) ───────────────
class GoalAddTool(Tool):
    name = "goal_add"
    description = "User ka ek naya goal add karta hai (priority: 1=urgent … 5=low, deadline optional)"
    parameters = {
        "type": "object",
        "properties": {
            "goal": {"type": "string"},
            "priority": {"type": "integer"},
            "deadline": {"type": "string", "description": "e.g. '2026-12-31' ya 'is hafte'"},
        },
        "required": ["goal"],
    }
    risk = "low"

    def __init__(self, goals):
        self.goals = goals

    def run(self, args):
        goal = str(args.get("goal", "")).strip()
        if not goal:
            raise ValueError("goal text chahiye")
        gid = self.goals.add(goal, args.get("priority", 3), args.get("deadline", ""))
        return f"🎯 Goal #{gid} add ho gaya: {goal}"


class GoalListTool(Tool):
    name = "goal_list"
    description = "User ke active goals dikhata hai (priority + deadline + progress)"
    parameters = {"type": "object", "properties": {}, "required": []}
    risk = "low"

    def __init__(self, goals):
        self.goals = goals

    def run(self, args):
        rows = self.goals.active(10)
        if not rows:
            return "Koi active goal nahi 🎯"
        lines = []
        for g in rows:
            line = f"#{g['id']} [P{g['priority']}] {g['goal']}"
            if g["deadline"]:
                line += f" — deadline: {g['deadline']}"
            if g["progress"]:
                line += f" ({g['progress']}%)"
            lines.append(line)
        return "\n".join(lines)


class GoalUpdateTool(Tool):
    name = "goal_update"
    description = "Goal update karta hai — status (active/done/archived) ya progress (0-100)"
    parameters = {
        "type": "object",
        "properties": {
            "goal_id": {"type": "integer"},
            "status": {"type": "string", "enum": ["active", "done", "archived"]},
            "progress": {"type": "integer"},
        },
        "required": ["goal_id"],
    }
    risk = "low"

    def __init__(self, goals):
        self.goals = goals

    def run(self, args):
        try:
            gid = int(args.get("goal_id"))
        except (TypeError, ValueError):
            raise ValueError("goal_id (number) chahiye")
        status = args.get("status")
        progress = args.get("progress")
        if status is None and progress is None:
            raise ValueError("status ya progress — kuch toh do")
        if not self.goals.update(gid, status, progress):
            raise ValueError(f"goal #{gid} nahi mila")
        return f"✅ Goal #{gid} update ho gaya"
